# Regulatory Notes

1. Kita bikin constant untuk nama-name header nya (LKBPU & LBABK)
2. Bikin mock data untuk LKBPU
3. Bikin mock data untuk LBABK
4. Ambil semua data LKBPU, harusnya berdasarlkan bulan dan tahun


# Data LKPBU

- Flag Detail
- Kode Komponen
- Golongan
- Sandi Perusahaan Asuransi/Reasuransi/Dana Pensiun *)
- Nama Perusahaan Asuransi/Reasuransi/Dana Pensiun *)
- Kode Efek
- Jenis
- Nomor Bilyet/Nomor Seri *)
- Nama Surat Berharga *)
- Lembar/Unit *)
- Interest Rate/Kupon *)
- Keterangan **)
- Dana Jaminan/Investasi *)
- Jenis Valuta
- Nilai Valuta Asal
- Tanggal Penerbitan
- Jatuh Tempo
- Golongan 
- Sandi Penerbit
- Nama Penerbit
- Negara Asal
- Pembayaran Kupon/Deviden/Bunga/Diskonto

# Data LBABK Sheet 1

- Flag Detail
- Kode Komponen
- Tanggal Transaksi
- Kode Jenis Efek
- Keterangan Jenis Efek
- Kode ISIN
- Kode Efek
- Nama Efek
- Kode Issuer
- Nama Issuer
- Kode Mata Uang
- Penyelesaian Transaksi Beli - Frekuensi
- Penyelesaian Transaksi Beli - Volume (Unit)
- Penyelesaian Transaksi Beli - Nilai
- % Penyelesaian Transaksi Beli - Investor Indonesia
- % Penyelesaian Transaksi Beli - Investor Asing
- % Penyelesaian Transaksi Beli - Konfirmasi Investor Tepat Waktu

- Penyelesaian Transaksi Jual - Frekuensi
- Penyelesaian Transaksi Jual - Volume (Unit)
- Penyelesaian Transaksi Jual - Nilai
- % Penyelesaian Transaksi Jual - Investor Indonesia
- % Penyelesaian Transaksi Jual - Investor Asing
- % Penyelesaian Transaksi Jual - Konfirmasi Investor Tepat Waktu

# DATA LBABK Sheet 2

- Flag Detail
- Kode Komponen
- Kode Tipe Efek
- Keterangan Tipe Efek
- Nilai (Rupiah)

# File Upload - Data Source

- ekstensi file nya apa aja, apakah CSV atau Excel
- Ada 3 file data source
- Apa parameter buat narik data dari Hiport? Harusnya parameter tersebut juga digunakan saat ngambil data dari data source yang sudah tersimpan di table

# Maintenance 
- ISIN Code
- ISSUER Code
- Bank
- Asuransi

# Data Source
- CUSACT
- Deposito
- LKPBUV

# Maintenance

- Asuransi dan Dana Pensiun --> dibikin upload file (InsurancePensionFund)
- ClosingRate (Exchange Rate) --> dibikin create satuan
- Golongan Pemilik --> dibikin upload file (Owner Group)
- Kode ISIN Efek --> dibikin upload file (Securities ISIN Code)
- Kode Issuer dan Placement Bank --> dibikin upload file (Issuer Code Placement Bank)
- Kode Issuer Efek --> dibikin upload file (Securities Issuer Code)

# Maintenance Name
- InsurancePensionFund
- ExchangeRate
- OwnerGroup
- SecuritiesISINCode
- IssuerCodePlacementBank
- SecuritiesIssuerCode

# Maintenance Exchange
- kurang logic service impl

# Owner Group
- kurang logic service impl

# ISIN Code
- kurang logic service impl

# Issuer Code Placement Bank
- ini pengganti Bank Code

# Sample Code for Insert or Update
```java
@Transactional
    @Override
    public String createMultiple(CreateBankCodeListRequest createBankCodeListRequest) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;

        for (CreateBankCodeRequest createBankCodeRequest : createBankCodeListRequest.getCreateBankCodeRequestList()) {
            try {
                // Check if the entity exists by code
                if (createBankCodeRequest.getCode() != null) {
                    Optional<BankCode> existingBankCode = bankCodeRepository.findByCode(createBankCodeRequest.getCode());

                    if (existingBankCode.isPresent()) {
                        // Update the existing entity
                        BankCode bankCode = existingBankCode.get();

                        // save
                    } else {
                        // create baru save entity
                        // tidak perlu ada logic disini
                    }
                } else {
                    // Create new entity
                    BankCode bankCode = BankCode.builder()
                            .code(createBankCodeRequest.getCode())
                            .name(createBankCodeRequest.getName())
                            .build();
                    bankCodeRepository.save(bankCode);
                }
                totalDataSuccess++;
            } catch (Exception e) {
                totalDataFailed++;
            }
        }
        return "Total data success: " + totalDataSuccess + ", and total data failed: " + totalDataFailed;
    }
```