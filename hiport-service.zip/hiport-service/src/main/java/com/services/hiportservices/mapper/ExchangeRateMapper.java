package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.exchangerate.ExchangeRateDTO;
import com.services.hiportservices.model.regulatory.ExchangeRate;
import com.services.hiportservices.utils.regulatory.ConversionUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;

@Mapper
public interface ExchangeRateMapper {

    ExchangeRateMapper INSTANCE = Mappers.getMapper(ExchangeRateMapper.class);

    @Mapping(source = "currencyCode", target = "code")
    @Mapping(source = "currencyName", target = "name")
    @Mapping(source = "exchangeRate", target = "exchangeRate", qualifiedByName = "stringToBigDecimal")
    ExchangeRate toModel(ExchangeRateDTO exchangeRateDTO);

    @Mapping(source = "code", target = "currencyCode")
    @Mapping(source = "name", target = "currencyName")
    @Mapping(source = "rate", target = "exchangeRate", qualifiedByName = "bigDecimalToString")
    ExchangeRateDTO toDTO(ExchangeRate exchangeRate);

    default BigDecimal stringToBigDecimal(String value) {
        return ConversionUtil.stringToBigDecimal(value);
    }

    default String bigDecimalToString(BigDecimal value) {
        return ConversionUtil.bigDecimalToString(value);
    }

}
