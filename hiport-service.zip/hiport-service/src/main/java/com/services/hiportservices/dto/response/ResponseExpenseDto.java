package com.services.hiportservices.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponseExpenseDto {
    private String id;
    private String ExpCode1;
    private String ExpVal1;
    private String ExpCode2;
    private String ExpVal2;
    private String ExpCode3;
    private String ExpVal3;
    private String ExpCode4;
    private String ExpVal4;
    private String ExpCode5;
    private String ExpVal5;
}
