package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Data
@Table(name = "ORCHIDXD15")
public class OrchidXd15 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "Tanggal")
    @Getter(AccessLevel.NONE)
    private Date Tanggal;

    @Transient
    @Getter(AccessLevel.NONE)
    private String TanggalStr;

    @Column(name = "Kode")
    private String Kode;

    @Column(name = "SBerharga")
    private BigDecimal SBerharga= BigDecimal.ZERO;

    @Column(name = "Efek")
    private BigDecimal Efek= BigDecimal.ZERO;

    @Column(name = "Saham")
    private BigDecimal Saham= BigDecimal.ZERO;

    @Column(name = "Warran")
    private BigDecimal Warran= BigDecimal.ZERO;

    @Column(name = "Kas")
    private BigDecimal Kas= BigDecimal.ZERO;

    @Column(name = "TInvestasi")
    private BigDecimal TInvestasi= BigDecimal.ZERO;

    @Column(name = "Biaya")
    private BigDecimal Biaya= BigDecimal.ZERO;

    @Column(name = "Pemegang")
    private BigDecimal Pemegang= BigDecimal.ZERO;

    @Column(name = "PAsing")
    private BigDecimal PAsing= BigDecimal.ZERO;

    @Column(name = "PLokal")
    private BigDecimal PLokal= BigDecimal.ZERO;

    @Column(name = "PAsing100")
    private BigDecimal PAsing100= BigDecimal.ZERO;

    @Column(name = "PLokal100")
    private BigDecimal PLokal100= BigDecimal.ZERO;

    @Column(name = "Unit10")
    private BigDecimal Unit10= BigDecimal.ZERO;

    @Column(name = "Unit")
    private BigDecimal Unit= BigDecimal.ZERO;

    @Column(name = "UnitBaru")
    private BigDecimal UnitBaru= BigDecimal.ZERO;

    @Column(name = "Lunas")
    private BigDecimal Lunas= BigDecimal.ZERO;

    @Column(name = "Jual")
    private BigDecimal Jual= BigDecimal.ZERO;

    @Column(name = "TLunas")
    private BigDecimal TLunas= BigDecimal.ZERO;

    @Column(name = "Tinggi")
    private BigDecimal Tinggi= BigDecimal.ZERO;

    @Column(name = "NABperUnit")
    private BigDecimal NABperUnit= BigDecimal.ZERO;

    @Column(name = "Efek10")
    private BigDecimal Efek10= BigDecimal.ZERO;

    @Column(name = "Efek5")
    private BigDecimal Efek5= BigDecimal.ZERO;

    @Column(name = "EfekBeli")
    private BigDecimal EfekBeli= BigDecimal.ZERO;

    @Column(name = "EfekJual")
    private BigDecimal EfekJual= BigDecimal.ZERO;

    @Column(name = "KomisiPE")
    private BigDecimal KomisiPE= BigDecimal.ZERO;

    @Column(name = "KomisiPEMI")
    private BigDecimal KomisiPEMI= BigDecimal.ZERO;

    @Column(name = "PortSBerharga")
    private BigDecimal PortSBerharga= BigDecimal.ZERO;

    @Column(name = "PortEfek")
    private BigDecimal PortEfek= BigDecimal.ZERO;

    @Column(name = "PortSaham")
    private BigDecimal PortSaham= BigDecimal.ZERO;

    @Column(name = "PortWarran")
    private BigDecimal PortWarran= BigDecimal.ZERO;

    @Column(name = "PortKas")
    private BigDecimal PortKas= BigDecimal.ZERO;

    @Column(name = "PROCESS_DATE")
    @Getter(AccessLevel.NONE)
    private Date PROCESS_DATE;

    @Transient
    @Getter(AccessLevel.NONE)
    private String PROCESS_DATE_STR;

    @Column(name = "PROCESS_STATUS")
    private String PROCESS_STATUS;

    @Column(name = "SInvestCode")
    private String SInvestCode;

    public String getPROCESS_DATE_STR() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(PROCESS_DATE);
    }

    public String getTanggalStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(Tanggal);
    }

}
