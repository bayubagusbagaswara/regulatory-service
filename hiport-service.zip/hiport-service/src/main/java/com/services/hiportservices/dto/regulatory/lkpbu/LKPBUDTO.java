package com.services.hiportservices.dto.regulatory.lkpbu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUDTO {

    private String flagDetail;

    private String componentCode;

    private String group;

    private String companyCode;

    private String companyName;

    private String effectCode;

    // securities issuer

    // securities owner

    // BUY
    private Integer settlementTransactionBuyFrequency;

    private BigDecimal settlementTransactionBuyVolume;

    private BigDecimal settlementTransactionBuyAmount;

    private BigDecimal settlementTransactionBuyInvestorIndonesia;

    // SELL
    private Integer settlementTransactionSellFrequency;

    private BigDecimal settlementTransactionSellVolume;

    private BigDecimal settlementTransactionSellAmount;

    private BigDecimal settlementTransactionSellInvestorIndonesia;

    // add data-data LKPBU constant
    private String kodeKomponen;
    private String golongan1;
    private String sandiPerusahaan;
    private String namaPerusahaan;
    private String kodeEfek;
    private String jenis;
    private String nomorBilyet;
    private String namaSuratBerharga;
    private String lembarUnit;
    private String interestRate;
    private String keterangan;
    private String danaJaminan;
    private String jenisValuta;
    private String nilaiValutaAsal;
    private String tanggalPenerbitan;
    private String jatuhTemppo;
    private String golongan2;
    private String sandiPenerbit;
    private String namaPenerbit;
    private String negaraAsal;
    private String pembayaranKupon;

}