package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.compliance.PortfolioType;
import com.services.hiportservices.model.compliance.ReksadanaType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface PortfolioTypeRepository extends JpaRepository<PortfolioType,Long> {

    PortfolioType findByPortfolioType(int portfolioCode);

    List<PortfolioType> findAllByDeleteAndApprovalStatus (boolean isDelete, ApprovalStatus approvalStatus);

    @Query("SELECT u FROM PortfolioType u WHERE u.description like %:description%")
    List<PortfolioType> searchByDescription(@Param("description") String description);

    @Query("SELECT u FROM PortfolioType u WHERE  u.approvalStatus = 'Pending' and u.delete = false")
    List<PortfolioType> searchPendingData();

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_portfolio_type SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE portfolio_type = :portfolioType", nativeQuery = true)
    void approveOrRejectPortfolioType(@Param("approvalStatus") String approvalStatus,
                                      @Param("approveDate") Date approveDate,
                                      @Param("approverId") String approverId,
                                      @Param("portfolioType") int portfolioType);

}
