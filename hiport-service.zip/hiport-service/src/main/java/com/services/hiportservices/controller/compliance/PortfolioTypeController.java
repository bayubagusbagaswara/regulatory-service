package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioTypeRequestDTO;
import com.services.hiportservices.service.compliance.PortfolioTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/portfolioType")
public class PortfolioTypeController {

    @Autowired
    PortfolioTypeService portfolioTypeService;

    @PostMapping
    public ResponseEntity<ResponseDto> save(@RequestBody PortfolioTypeRequestDTO pfTypeDTO)  {
        return portfolioTypeService.insertPortfolioType(pfTypeDTO);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> getAllPortfolioType()  {
        return portfolioTypeService.getAllByDelete();
    }

    @GetMapping("/{pfType}")
    public ResponseEntity<ResponseDto> getById(@PathVariable int pfType)  {
        return portfolioTypeService.getByPortfolioType(pfType);
    }

    @PutMapping("/delete/{id}")
    public ResponseEntity<ResponseDto> deleteById(@PathVariable int id)  {
        return portfolioTypeService.deleteById(id);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return portfolioTypeService.allPendingDataPortfolioType();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return portfolioTypeService.approveDataPortfolioType(codeList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return portfolioTypeService.rejectDataPortfolioType(codeList);
    }
}
