
package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_pup")
public class PUP extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "pup_total")
    private int pupTotal;
}
