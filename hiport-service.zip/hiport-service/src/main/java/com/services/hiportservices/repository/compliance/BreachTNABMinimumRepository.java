package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.BreachReport;
import com.services.hiportservices.model.compliance.BreachTNABMinimum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BreachTNABMinimumRepository extends JpaRepository<BreachTNABMinimum,Long> {

    @Query(value="SELECT * FROM comp_breach_tnab WHERE data_date = :dataDate", nativeQuery = true)
    List<BreachTNABMinimum> searchDataAt(@Param("dataDate") String dataDate);


    @Query(value="SELECT * FROM comp_breach_tnab WHERE data_date = :dataDate AND tnab_minimum = :tnabMin AND breach = :breach", nativeQuery = true)
    List<BreachTNABMinimum> searchDataByDateAndTnabMinAndBreach(@Param("dataDate") String dataDate,
                                                                @Param("tnabMin") double tnabMin,
                                                                @Param("breach") String breach);
}
