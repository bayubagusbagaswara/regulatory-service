package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.AddDeletePortfolioKINVRequestDTO;
import com.services.hiportservices.dto.request.compliance.KINVReksadanaRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


@Service
public class PortfolioKINVGroupingService {

    @Autowired
    KINVReksadanaRepository kinvReksadanaRepository;
    @Autowired
    ReksadanaRepository reksadanaRepository;
    @Autowired
    MasterKebijakanInvestasiRepository masterKebijakanInvestasiRepository;
    @Autowired
    PortfolioKINVGroupingRepository portfolioKINVGroupingRepository;
    @Autowired
    PortfolioRepository portfolioRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;

    @Transactional
    public ResponseEntity<ResponseDto> insertMappingPortfolioKinv(AddDeletePortfolioKINVRequestDTO addDeletePortfolioKINVRequestDTO) {
        String message = "Insert new mapping portfolio to reksadana";
        ResponseDto responseDto = new ResponseDto();
        try {
            Reksadana reksadana = reksadanaRepository.findByCode(addDeletePortfolioKINVRequestDTO.getReksadanaCode());
            if (addDeletePortfolioKINVRequestDTO.getAddPortfolio() != "") {
                String[] addArray = addDeletePortfolioKINVRequestDTO.getAddPortfolio().split(",");
                List<String> listPortfolio = Arrays.asList(addArray);
                for (String code : listPortfolio) {
                    Portfolio portfolio = portfolioRepository.findByCode(code);
                    System.out.println("ADD Portfolio: " + code + " Type: " + portfolio.getPortfolioType().getPortfolioType() + " from Reksadana: " + reksadana.getCode().trim());
                    PortfolioKINVGrouping portfolioKINV = new PortfolioKINVGrouping();
                    portfolioKINV.setApprovalStatus(ApprovalStatus.Pending);
                    portfolioKINV.setInputDate(new Date());
                    portfolioKINV.setInputerId(UserIdUtil.getUser());
                    portfolioKINV.setPortfolio(portfolio);
                    portfolioKINV.setPortfolioType(portfolio.getPortfolioType());
                    portfolioKINV.setReksadanaCode(reksadana);
                    portfolioKINV.setRdExternalCode(reksadana.getExternalCode());
                    portfolioKINVGroupingRepository.save(portfolioKINV);
                }
            }

            if (addDeletePortfolioKINVRequestDTO.getDeletePortfolio() != "") {
                message = "Delete mapping portfolio to KINV";
                String[] addArray = addDeletePortfolioKINVRequestDTO.getDeletePortfolio().split(",");
                List<String> listPortfolio = Arrays.asList(addArray);
                List<ComplianceDataChange> complianceDataChangeList = new ArrayList<>();
                for (String code : listPortfolio) {
//                    System.out.println("DELETE Portfolio: " + code + " from Reksadana: " +reksadana.getCode()+ " KINV: " + masterKebijakanInvestasi.getKinvCode());
                    Portfolio portfolio = portfolioRepository.findByCode(code);
                    PortfolioKINVGrouping portfolioKINVGrouping = portfolioKINVGroupingRepository.searchByReksadanaCodeAndPortfolio(reksadana,portfolio);
                    ComplianceDataChange complianceDataChange = new ComplianceDataChange();
                    if(portfolioKINVGrouping != null){
                        complianceDataChange = deleteDataToDataChaenge(portfolioKINVGrouping);
                    } else {
                        throw new Exception("This Portfolio are not mapped to Reksadana!");
                    }
                    complianceDataChangeList.add(complianceDataChange);
                }
                complianceDataChangeRepository.saveAll(complianceDataChangeList);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findByReksadanaCode(String reksadanaCode) {
//        Reksadana reksadana = reksadanaRepository.findByCode(reksadanaCode.trim());
        Reksadana reksadana = reksadanaRepository.findByCode(reksadanaCode);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioKINVGroupingRepository.searchByReksadanaCode(reksadana));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<ResponseDto> insertMappingPortfolioUpload(String param, List<Map<String, String>> portfolioMappingList) {
        String message = "Input data success!";
        ResponseDto responseDto = new ResponseDto();
        List<PortfolioKINVGrouping> newPortfolioKINVGroupingList = new ArrayList<>();
        try {
            if (param.equalsIgnoreCase("new")) {
                int row = 1;
                for (Map<String, String> portfolioMapping : portfolioMappingList) {
                    row += 1;
                    String reksadanaCode = portfolioMapping.get("reksadanaCode").trim();
                    String portfolioCode = portfolioMapping.get("portfolio").trim();
                    String portfolioType = portfolioMapping.get("portfolioType").trim();

                    if (reksadanaCode == "" || reksadanaCode == null || portfolioCode == "" || portfolioCode == null ||
                            portfolioType == "" || portfolioType == null) {
                        throw new Exception("Required properties are missing in Row: " + row);
                    }

                    Reksadana reksadana = reksadanaRepository.findByCodeAndDelete(reksadanaCode, false);
                    if (reksadana == null) {
                        throw new Exception("Row: " + row + " Reksadana " + reksadanaCode + " not exist!");
                    }
                    Portfolio portfolio = portfolioRepository.findByCode(portfolioCode);
                    if (portfolio == null) {
                        throw new Exception("Row: " + row + " Portfolio " + portfolioCode + " not exist!");
                    }

                    PortfolioKINVGrouping portfolioKINVGrouping = portfolioKINVGroupingRepository.searchByReksadanaCodeAndPortfolio(reksadana, portfolio);

                    if (portfolioKINVGrouping == null){
                        portfolioKINVGrouping = new PortfolioKINVGrouping();
                        portfolioKINVGrouping.setReksadanaCode(reksadana);
                        portfolioKINVGrouping.setPortfolio(portfolio);
                    }

                    if(reksadana.getExternalCode() == "" || reksadana.getExternalCode() == null){
                        throw new Exception("Row: " + row + " External Code for " + reksadanaCode + " is Empty! Please Fill It!");
                    } else {
                        portfolioKINVGrouping.setRdExternalCode(reksadana.getExternalCode());
                    }

                    if(portfolio.getPortfolioType().getPortfolioType() != Integer.valueOf(portfolioType)){
                        throw new Exception("Row: " + row + " Inputed Portfolio Type is not match with Portfolio Type In Database! Please Check It!");
                    } else {
                        portfolioKINVGrouping.setPortfolioType(portfolio.getPortfolioType());
                    }

                    portfolioKINVGrouping.setApprovalStatus(ApprovalStatus.Pending);
                    portfolioKINVGrouping.setInputerId(UserIdUtil.getUser());
                    portfolioKINVGrouping.setInputDate(new Date());

                    newPortfolioKINVGroupingList.add(portfolioKINVGrouping);
                }
                portfolioKINVGroupingRepository.saveAll(newPortfolioKINVGroupingList);
            } else if (param.equalsIgnoreCase("delete")) {
                int row = 1;
                List<ComplianceDataChange> complianceDataChangeList = new ArrayList<>();
                for (Map<String, String> portfolioMapping : portfolioMappingList) {
                    row += 1;
                    String reksadanaCode = portfolioMapping.get("reksadanaCode").trim();
                    String portfolioCode = portfolioMapping.get("portfolio").trim();
                    String portfolioType = portfolioMapping.get("portfolioType").trim();

                    if (reksadanaCode == "" || reksadanaCode == null || portfolioCode == "" || portfolioCode == null) {
                        throw new Exception("Required properties are missing in Row: " + row);
                    }

                    Reksadana reksadana = reksadanaRepository.findByCodeAndDelete(reksadanaCode, false);
                    if (reksadana == null) {
                        throw new Exception("Row: " + row + " Reksadana " + reksadanaCode + " not exist!");
                    }

                    Portfolio portfolio = portfolioRepository.findByCode(portfolioCode);
                    if (portfolio == null) {
                        throw new Exception("Row: " + row + " Portfolio " + portfolioCode + " not exist!");
                    }

                    PortfolioKINVGrouping portfolioKINVGrouping = portfolioKINVGroupingRepository.searchByReksadanaCodeAndPortfolio(reksadana, portfolio);

                    ComplianceDataChange complianceDataChange = new ComplianceDataChange();
                    if(portfolioKINVGrouping != null){
                        complianceDataChange = deleteDataToDataChaenge(portfolioKINVGrouping);
                    } else {
                        throw new Exception("Row " + row + ": This Portfolio are not mapped to Reksadana!");
                    }

//                    complianceDataChangeList = deleteDataToDataChaenge(portfolioKINVGrouping);

                    complianceDataChangeList.add(complianceDataChange);
                }
                complianceDataChangeRepository.saveAll(complianceDataChangeList);
                message = "Delete data success!";
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);

        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }


    private static ComplianceDataChange deleteDataToDataChaenge(PortfolioKINVGrouping portfolioKINVGrouping){
        ComplianceDataChange dataChange = new ComplianceDataChange();
        try {
            PortfolioKINVGrouping portfolioKINVGroupingAfter = new PortfolioKINVGrouping();

            ObjectMapper Obj = new ObjectMapper();
            String jsonbefore = Obj.writeValueAsString(portfolioKINVGrouping);
            ObjectMapper ObjAfter = new ObjectMapper();
            String jsonAfter = ObjAfter.writeValueAsString(portfolioKINVGroupingAfter);

            dataChange.setApprovalStatus(ApprovalStatus.Pending);
            dataChange.setInputerId(UserIdUtil.getUser());
            dataChange.setInputDate(new Date());
            dataChange.setAction(ChangeAction.Delete);
            dataChange.setEntityId(String.valueOf(portfolioKINVGrouping.getId()));
            dataChange.setTableName("comp_mapping_portfolio");
            dataChange.setEntityClassName(PortfolioKINVGrouping.class.getName());
            dataChange.setDataBefore(jsonbefore);
            dataChange.setDataChange(jsonAfter);

        }catch (Exception e){
            e.printStackTrace();
        }
       return dataChange;
    }

    public ResponseEntity<ResponseDto> allPendingDataMapping() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioKINVGroupingRepository.searchPendingMappingData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataMapping(Map<String, List<String>> codeList) {
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            portfolioKINVGroupingRepository.approveOrRejectMappingPortfolio("Approved", new Date(), approverId, Long.valueOf(code));
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataMapping(Map<String, List<String>> codeList) {
        ResponseDto responseDto = new ResponseDto();
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        try {
            for (String code : codes){
                PortfolioKINVGrouping portfolioKINVGrouping = portfolioKINVGroupingRepository.findById(Long.valueOf(code)).orElseThrow(() -> new RuntimeException("Data Not Found!"));
                portfolioKINVGroupingRepository.delete(portfolioKINVGrouping);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have rejected!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
