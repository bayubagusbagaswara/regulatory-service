package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.FairPrice;
import com.services.hiportservices.model.compliance.NabKPD;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface NabKPDRepository extends JpaRepository<NabKPD,Long> {

    @Transactional
    @Modifying
    @Query(value="INSERT INTO comp_nab_kpd (approval_status, inputer_id, input_date, data_date, kpd_code, nab)"
            + " VALUES ('Pending', :inputerId, :inputDate, :dataDate, :kpdCode, :nab)", nativeQuery = true)
    void insertIntoNabKpd(@Param("inputerId") String inputerId,
                                     @Param("inputDate") Date inputDate,
                                     @Param("dataDate") Date dataDate,
                                     @Param("kpdCode") String kpdCode,
                                     @Param("nab") double nab);

    @Query("SELECT u FROM NabKPD u WHERE u.date = :date and u.approvalStatus = 'Pending'")
    List<NabKPD> searchPendingNabKpdDataByDate(@Param("date") Date date);

    @Query("SELECT u FROM NabKPD u WHERE u.date = :date and u.approvalStatus = 'Approved'")
    List<NabKPD> searchApproveNabKpdDataByDate (@Param("date") Date date);

    NabKPD findByDateAndKpdCode (Date date, String kpdCode);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_nab_kpd SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE data_date = :dataDate", nativeQuery = true)
    void approveOrRejectNabKpd(@Param("approvalStatus") String approvalStatus,
                                     @Param("approveDate") Date approveDate,
                                     @Param("approverId") String approverId,
                                     @Param("dataDate") String dataDate);

}
