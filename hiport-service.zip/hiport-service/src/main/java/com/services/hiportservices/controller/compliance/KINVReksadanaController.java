package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.KINVReksadanaRequestDTO;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.service.compliance.KINVReksadanaService;
import com.services.hiportservices.service.compliance.PortfolioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/kinvRegis")
public class KINVReksadanaController {
    @Autowired
    KINVReksadanaService kinvReksadanaService;

//    @PostMapping
//    public ResponseEntity<ResponseDto> saveList(@RequestBody List<KINVReksadanaRequestDTO> kinvReksadanaRequestDTO)  {
//        return kinvReksadanaService.insertListKinvReksadana(kinvReksadanaRequestDTO);
//    }

//    @GetMapping
//    public ResponseEntity<ResponseDto> getAllPortfolioType()  {
//        return kinvReksadanaService.getAllApprovedData();
//    }
//
    @GetMapping("/{code}")
    public ResponseEntity<ResponseDto> getByCode(@PathVariable String code)  {
        return kinvReksadanaService.getByReksadanaCode(code);
    }

//    @PutMapping("/delete/{code}")
//    public ResponseEntity<ResponseDto> deleteById(@PathVariable String code)  {
//        return kinvReksadanaService.deleteByCode(code);
//    }

    @PutMapping("/upload/{param}")
    public ResponseEntity<ResponseDto> uploadFileKinvReksadana(@PathVariable String param, @RequestBody List<Map<String, String>> kinvRekasadanaList) {
        return kinvReksadanaService.insertKinvReksadanaUpload(param, kinvRekasadanaList);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return kinvReksadanaService.allPendingDataKinvReksadana();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithId(@RequestBody Map<String, List<String>> idList) {
        return kinvReksadanaService.approveDataKinvReksadana(idList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithId(@RequestBody Map<String, List<String>> idList) {
        return kinvReksadanaService.rejectDataKinvReksadana(idList);
    }
}
