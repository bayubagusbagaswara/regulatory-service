package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.controller.MasterController;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.KebijakanInvRequestDto;
import com.services.hiportservices.service.compliance.MasterKebijakanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/kinv")
public class MasterKebijakanController {
    @Autowired
    MasterKebijakanService masterKebijakanService;

    Logger logger = LoggerFactory.getLogger(MasterKebijakanController.class);


    @PostMapping
    public ResponseEntity<ResponseDto> save(@RequestBody KebijakanInvRequestDto kebijakanInvRequestDto)  {
        return masterKebijakanService.insertMasterKebijakan(kebijakanInvRequestDto);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> getAllKebijakanInvest()  {
        return masterKebijakanService.getAllByDelete();
    }

//    @PutMapping("update/{code}")
//    public ResponseEntity<ResponseDto> updateKebijakan(@PathVariable String code, @RequestBody KebijakanInvRequestDto kebijakanInvRequestDto) throws Exception {
//        logger.info("Update Kebijakan where Code = " + code);
//        return masterKebijakanService.getUpdate(code,kebijakanInvRequestDto);
//    }

    @GetMapping("/{code}")
    public ResponseEntity<ResponseDto> getById(@PathVariable String code)  {
        return masterKebijakanService.getByCode(code);
    }

    @PutMapping("/delete/{code}")
    public ResponseEntity<ResponseDto> deleteByCode(@PathVariable String code)  {
        return masterKebijakanService.deleteByCode(code);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return masterKebijakanService.allPendingDataKinv();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithId(@RequestBody Map<String, List<String>> idList) {
        return masterKebijakanService.approveDataKinv(idList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithId(@RequestBody Map<String, List<String>> idList) {
        return masterKebijakanService.rejectDataKinv(idList);
    }
}
