package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_xd14_temp")
public class TemporaryXD14 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_xd14")
    private Long id;

    @Column(name = "DATE_PROC")
    private Date dateProc;

    @Column(name = "STAT_PROC")
    private String statProc;

    @Column(name = "Tanggal")
    private Date tanggal;

    @Column(name = "Kode")
    private String kode;

    @Column(name = "Portofolio")
    private String portofolio;

    @Column(name = "Tipe")
    private String tipe;

    @Column(name = "NilaiBeli")
    private BigDecimal nilaiBeli;

    @Column(name = "Jumlah")
    private BigDecimal jumlah;

    @Column(name = "TJTempo")
    private Date tjTempo;

    @Column(name = "Nilai")
    private BigDecimal nilai;

    @Column(name = "Total")
    private BigDecimal total;

    @Column(name = "PersenAsset")
    private BigDecimal persenAsset;

    @Column(name = "Bunga")
    private BigDecimal bunga;

    @Column(name = "SecurityCode")
    private String securityCode;

    @Column(name = "SECTYPE")
    private String sectype;

    @Column(name = "REPORTGROUP")
    private String reportGroup;

    @Column(name = "NAV")
    private BigDecimal nav;

    @Column(name = "counter")
    private String counter;

    @Column(name = "displayPortfolio")
    private String dsplyPorto;

    @Column(name = "IssuerCode")
    private String issuerCode;

    @Column(name = "ReksadanaCode")
    private String reksadanaCode;

}
