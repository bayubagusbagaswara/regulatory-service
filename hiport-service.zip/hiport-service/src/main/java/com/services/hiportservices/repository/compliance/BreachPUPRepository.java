package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.BreachPUP;
import com.services.hiportservices.model.compliance.BreachReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BreachPUPRepository extends JpaRepository<BreachPUP,Long> {

    @Query(value="SELECT * FROM comp_breach_pup WHERE data_date = :dataDate", nativeQuery = true)
    List<BreachPUP> searchDataAt(@Param("dataDate") String dataDate);
}
