package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.isincode.*;
import com.services.hiportservices.repository.regulatory.SecuritiesISINCodeRepository;
import com.services.hiportservices.service.regulatory.SecuritiesISINCodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecuritiesISINCodeServiceImpl implements SecuritiesISINCodeService {

    private final SecuritiesISINCodeRepository securitiesISINCodeRepository;

    @Override
    public ISINCodeResponse createMultipleData(CreateISINCodeListRequest createISINCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ISINCodeResponse createSingleData(CreateISINCodeRequest createISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ISINCodeResponse createSingleApprove(ISINCodeApproveRequest isinCodeApproveRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public ISINCodeResponse updateMultipleData(UpdateISINCodeListRequest updateISINCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ISINCodeResponse updateSingleData(UpdateISINCodeRequest updateISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ISINCodeResponse updateSingleApprove(ISINCodeApproveRequest isinCodeApproveRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public ISINCodeResponse deleteSingleData(DeleteISINCodeRequest deleteISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ISINCodeResponse deleteSingleApprove(ISINCodeApproveRequest isinCodeApproveRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public ISINCodeDTO getById(Long id) {
        return null;
    }

    @Override
    public ISINCodeDTO getByExternalCode(String externalCode) {
        return null;
    }

    @Override
    public List<ISINCodeDTO> getAll() {
        return null;
    }
}
