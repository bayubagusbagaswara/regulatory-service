package com.services.hiportservices.controller.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.model.compliance.NabKPD;
import com.services.hiportservices.service.compliance.FairPriceService;
import com.services.hiportservices.service.compliance.NabKPDService;
import lombok.Cleanup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/nabKPD")
public class NabKPDController {

    @Autowired
    NabKPDService nabKPDService;

    @PostMapping("/upload")
    public ResponseEntity<ResponseDto> uploadFile(@RequestParam("file") MultipartFile file) {
        System.out.println(file.getOriginalFilename());
        return nabKPDService.insertDataNabKpd(file);
    }

    @GetMapping("/{date}")
    public ResponseEntity<ResponseDto> getAllDataAt(@PathVariable String date) {
        return nabKPDService.findDataAt(date);
    }
//
    @GetMapping("/viewPending/{date}")
    public ResponseEntity<ResponseDto> viewPendingData(@PathVariable String date) {
        return nabKPDService.viewPendingData(date);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return nabKPDService.allPendingDataNabKpd();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataAt(@RequestBody Map<String, List<String>> dates) {
        return nabKPDService.approveDataNabKpd(dates);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataAt(@RequestBody Map<String, List<String>> dates) {
        return nabKPDService.rejectDataNabKpd(dates);
    }

}
