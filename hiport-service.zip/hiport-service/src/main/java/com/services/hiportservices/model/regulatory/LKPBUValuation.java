package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "regulatory_lkpbuv")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUValuation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "valuation_date")
    private LocalDate valuationDate;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "security")
    private String security;

    @Column(name = "external_code_1")
    private String externalCode1;

    @Column(name = "security_currency")
    private String securityCurrency;

    @Column(name = "long_name")
    private String longName;

    @Column(name = "unit_holding")
    private BigDecimal unitHolding;

    @Column(name = "total_value")
    private BigDecimal totalValue;

    @Column(name = "issue_date")
    private LocalDate issueDate;

    @Column(name = "mat_date")
    private LocalDate matDate;

    @Column(name = "golongan_pemilik")
    private String golonganPemilik;

    @Column(name = "perusahaan_asuransi")
    private String perusahaanAsuransi;

    @Column(name = "negara_pemilik")
    private String negaraPemilik;

    @Column(name = "dana_jaminan")
    private String danaJaminan;

    @Column(name = "golongan_penerbit")
    private String golonganPenerbit;

    @Column(name = "negara_penerbit")
    private String negaraPenerbit;

    @Column(name = "isin_code")
    private String isinCode;

    @Column(name = "jenis_apolo")
    private String jenisApolo;

    @Column(name = "issuer_lkpbu")
    private String issuerLKPBU;

    @Column(name = "code_tipe_ap_1")
    private String codeTipeAP1;

    @Column(name = "code_tipe_ap_2")
    private String codeTipeAP2;

    @Column(name = "client_status")
    private String clientStatus;

    @Column(name = "external_code_2")
    private String externalCode2;

    @Column(name = "coupon_rate")
    private BigDecimal couponRate;

    @Column(name = "customer_type")
    private String customerType;

    @Column(name = "system")
    private String system;

}
