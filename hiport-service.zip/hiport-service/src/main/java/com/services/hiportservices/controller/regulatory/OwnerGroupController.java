package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.*;
import com.services.hiportservices.service.regulatory.OwnerGroupService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Golongan Pemilik
 */
@RestController
@RequestMapping(path = "/api/regulatory/golongan-pemilik")
@Slf4j
@RequiredArgsConstructor
public class OwnerGroupController {

    private static final String BASE_URL_OWNER_GROUP = "/api/regulatory/golongan-pemilik";
    private static final String MENU_OWNER_GROUP = "Golongan Pemilik";

    private final OwnerGroupService ownerGroupService;

    /* Create or Update List Data */
    @PostMapping(path = "/upload-list")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> createMultiple(@RequestBody UploadOwnerGroupListRequest uploadOwnerGroupListRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(BASE_URL_OWNER_GROUP + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_OWNER_GROUP)
                .build();

        OwnerGroupResponse listData = ownerGroupService.uploadListData(uploadOwnerGroupListRequest, regulatoryDataChangeDTO);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Create Single Data (in addition) */
    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> createSingle(@RequestBody CreateOwnerGroupRequest createOwnerGroupRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(BASE_URL_OWNER_GROUP + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_OWNER_GROUP)
                .build();

        OwnerGroupResponse singleData = ownerGroupService.createSingleData(createOwnerGroupRequest, regulatoryDataChangeDTO);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Create Single Approve */
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> createSingleApprove(@RequestBody OwnerGroupApproveRequest ownerGroupApproveRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse singleApprove = ownerGroupService.createSingleApprove(ownerGroupApproveRequest, clientIP);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Update Single Data (in addition) */
    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> updateSingleData(@RequestBody UpdateOwnerGroupRequest updateOwnerGroupRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(BASE_URL_OWNER_GROUP + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_OWNER_GROUP)
                .build();
        OwnerGroupResponse singleData = ownerGroupService.updateSingleData(updateOwnerGroupRequest, regulatoryDataChangeDTO);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Update Single Approve */
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> updateSingleApprove(@RequestBody OwnerGroupApproveRequest ownerGroupApproveRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse singleApprove = ownerGroupService.updateSingleApprove(ownerGroupApproveRequest, clientIP);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Delete Single Data */
    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> deleteSingleData(@RequestBody DeleteOwnerGroupRequest deleteOwnerGroupRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse deleteSingle = ownerGroupService.deleteSingleData(deleteOwnerGroupRequest, clientIP);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteSingle)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Delete Single Approve */
    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> deleteSingleApprove(@RequestBody OwnerGroupApproveRequest ownerGroupApproveRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse singleApprove = ownerGroupService.deleteSingleApprove(ownerGroupApproveRequest, clientIP);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* get by id */
    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDto<OwnerGroupDTO>> getById(@PathVariable("id") Long id) {
        OwnerGroupDTO ownerGroupDTO = ownerGroupService.getById(id);
        ResponseDto<OwnerGroupDTO> response = ResponseDto.<OwnerGroupDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ownerGroupDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    /* get by portfolio code */
    @GetMapping(path = "/portfolio-code")
    public ResponseEntity<ResponseDto<OwnerGroupDTO>> getByPortfolioCode(@RequestParam("portfolioCode") String portfolioCode) {
        OwnerGroupDTO ownerGroupDTO = ownerGroupService.getByPortfolioCode(portfolioCode);
        ResponseDto<OwnerGroupDTO> response = ResponseDto.<OwnerGroupDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ownerGroupDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    /* get all */
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<OwnerGroupDTO>>> getAll() {
        List<OwnerGroupDTO> ownerGroupDTOList = ownerGroupService.getAll();
        ResponseDto<List<OwnerGroupDTO>> response = ResponseDto.<List<OwnerGroupDTO>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ownerGroupDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
