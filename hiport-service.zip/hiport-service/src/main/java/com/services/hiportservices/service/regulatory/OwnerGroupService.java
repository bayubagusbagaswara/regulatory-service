package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.CreateOwnerGroupRequest;
import com.services.hiportservices.dto.regulatory.ownergroup.DeleteOwnerGroupRequest;
import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupApproveRequest;
import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupResponse;
import com.services.hiportservices.dto.regulatory.ownergroup.UpdateOwnerGroupRequest;
import com.services.hiportservices.dto.regulatory.ownergroup.UploadOwnerGroupListRequest;

import java.util.List;

public interface OwnerGroupService {

    // create multiple data
    OwnerGroupResponse uploadListData(UploadOwnerGroupListRequest uploadOwnerGroupListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    // create single data (in addition)
    OwnerGroupResponse createSingleData(CreateOwnerGroupRequest createOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    // create single approve
    OwnerGroupResponse createSingleApprove(OwnerGroupApproveRequest ownerGroupApproveRequest, String clientIP);

    // update single data (in addition)
    OwnerGroupResponse updateSingleData(UpdateOwnerGroupRequest updateOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    // update single approve
    OwnerGroupResponse updateSingleApprove(OwnerGroupApproveRequest ownerGroupApproveRequest, String clientIP);

    // delete single data
    OwnerGroupResponse deleteSingleData(DeleteOwnerGroupRequest deleteOwnerGroupRequest, String clientIP);

    // delete single approve
    OwnerGroupResponse deleteSingleApprove(OwnerGroupApproveRequest ownerGroupApproveRequest, String clientIP);

    OwnerGroupDTO getById(Long id);

    OwnerGroupDTO getByPortfolioCode(String portfolioCode);

    List<OwnerGroupDTO> getAll();

}
