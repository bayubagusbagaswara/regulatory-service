package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

import java.util.Date;

@Data
public class BreachRdTypeAndSecTypeRequestDTO {
    private Long id;
    private Date date;
    private String reksadanaCode;
    private String rdExternalCode;
    private String breachType;
    private String description;
}
