package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Data
@Table(name = "ORCHIDXD14")
public class OrchidXd14 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_xd14")
    private Long id;

    @Column(name = "DATE_PROC")
    private Date dateProc;

    @Transient
    @Getter(AccessLevel.NONE)
    private String dateProcStr;

    @Column(name = "STAT_PROC")
    private String statProc;

    @Column(name = "Tanggal")
    private Date tanggal;

    @Transient
    @Getter(AccessLevel.NONE)
    private String tanggalStr;

    @Column(name = "Kode")
    private String kode;

    @Column(name = "Portofolio")
    private String portofolio;

    @Column(name = "Tipe")
    private String tipe;

    @Column(name = "NilaiBeli")
    private BigDecimal nilaiBeli = BigDecimal.ZERO;

    @Column(name = "Jumlah")
    private BigDecimal jumlah = BigDecimal.ZERO;

    @Column(name = "TJTempo")
    private Date tjTempo ;

    @Column(name = "Nilai")
    private BigDecimal nilai = BigDecimal.ZERO;

    @Column(name = "Total")
    private BigDecimal total= BigDecimal.ZERO;

    @Column(name = "PersenAsset")
    private BigDecimal persenAsset= BigDecimal.ZERO;

    @Column(name = "Bunga")
    private BigDecimal bunga= BigDecimal.ZERO;

    @Column(name = "SecurityCode")
    private String securityCode = "";

    @Column(name = "SECTYPE")
    private String sectype = "";

    @Column(name = "REPORTGROUP")
    private String reportGroup = "";

    @Column(name = "NAV")
    private BigDecimal nav = BigDecimal.ZERO;

    @Column(name = "counter")
    private String counter;

    @Column(name = "displayPortfolio")
    private String dsplyPorto = "";

    @Column(name = "IssuerCode")
    private String issuerCode = "";

    @Column(name = "ReksadanaCode")
    private String reksadanaCode = "";

    public String getTanggalStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(tanggal);
    }

    public String getDateProcStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(dateProc);
    }

}
