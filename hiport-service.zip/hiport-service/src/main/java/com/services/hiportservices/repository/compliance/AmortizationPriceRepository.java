package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Repository
public interface AmortizationPriceRepository extends JpaRepository<AmortizationPrice,Long> {

    @Query("SELECT u FROM AmortizationPrice u WHERE u.date between :startDate and :endDate and u.approvalStatus = 'Approved'")
    List<AmortizationPrice> searchByDataDate(@Param("startDate") Date startDate,
                                             @Param("endDate") Date endDate);

    AmortizationPrice findByDateAndReksadanaCodeAndSecurityCode(Date date, String reksadanaCode, String securityCode);

    @Transactional
    @Modifying
    @Query(value="INSERT INTO comp_amortization_price (approval_status, inputer_id, input_date, data_date, reksadana_code, security_code, price)"
            + " VALUES ('Pending', :inputerId, :inputDate, :dataDate, :reksadanaCode, :securityCode, :price)", nativeQuery = true)
    void insertIntoAmortizationPrice(@Param("inputerId") String inputerId,
                       @Param("inputDate") Date inputDate,
                       @Param("dataDate") Date dataDate,
                       @Param("reksadanaCode") String reksadanaCode,
                       @Param("securityCode") String securityCode,
                       @Param("price") double price);

    @Query("SELECT u FROM AmortizationPrice u WHERE  u.approvalStatus = 'Pending'")
    List<AmortizationPrice> searchPendingData();

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_amortization_price SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE id = :id", nativeQuery = true)
    void approveOrRejectAmortization(@Param("approvalStatus") String approvalStatus,
                                  @Param("approveDate") Date approveDate,
                                  @Param("approverId") String approverId,
                                  @Param("id") Long id);

}
