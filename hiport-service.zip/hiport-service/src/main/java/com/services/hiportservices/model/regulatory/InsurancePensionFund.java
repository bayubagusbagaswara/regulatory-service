package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.Approvable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Asuransi dan Dana Pensiun
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "regulatory_insurance")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsurancePensionFund extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "portfolio_name")
    private String portfolioName;

    @Column(name = "regulator_name")
    private String regulatorName;

    @Column(name = "ref_insurance_pension_fund")
    private String referenceInsurancePensionFund;

    @Column(name = "guarantee_fund")
    private String guaranteeFund;

}
