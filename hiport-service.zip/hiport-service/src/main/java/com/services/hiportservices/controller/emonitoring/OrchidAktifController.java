package com.services.hiportservices.controller.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.model.emonitoring.OrchidXdAktif;
import com.services.hiportservices.service.emonitoring.OrchidAktifService;
import com.services.hiportservices.service.emonitoring.OrchidXd14Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/aktif")
public class OrchidAktifController {
    @Autowired
    OrchidAktifService orchidAktifService;

    @GetMapping("/updateAndInsert")
    public List<OrchidXdAktif> updateAndInsertXDAktif(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf,
            @RequestParam(name = "group", required = false) String group

    ) throws ClassNotFoundException, SQLException, IOException {
        System.out.println(date);
        System.out.println(pf);

        return orchidAktifService.insertOrUpdateAll(date, pf, group);
    }

    @GetMapping("/getDataAktif")
    public List<OrchidXdAktif> getDataAktif(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidAktifService.getDataAktif(date, pf);
    }
}
