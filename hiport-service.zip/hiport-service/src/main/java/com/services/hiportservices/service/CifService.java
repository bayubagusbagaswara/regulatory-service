package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class CifService {
    public ResponseEntity<ResponseDto> updateCif(String id){
        return ResponseEntity.ok(new ResponseDto().builder().code(HttpStatus.OK.toString()).message("Berhasil update data S4").payload(id).build());
    }
}
