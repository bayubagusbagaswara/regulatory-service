package com.services.hiportservices.controller.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.model.emonitoring.OrchidXd15;
import com.services.hiportservices.service.emonitoring.OrchidXd14Service;
import com.services.hiportservices.service.emonitoring.OrchidXd15Service;
import com.services.hiportservices.service.emonitoring.OrchidXd16Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd15")
public class OrchidXD15Controller {
    @Autowired
    OrchidXd15Service orchidXd15Service;

    @GetMapping("/updateAndInsert")
    public List<OrchidXd15> updateAndInsertXD14(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException, IOException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd15Service.insertOrUpdateAll(date, pf);
    }

    @GetMapping("/getDataXD15")
    public List<OrchidXd15> getDataXD14(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd15Service.getDataXD15(date, pf);
    }
}
