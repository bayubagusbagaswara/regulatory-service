package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd12;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;import java.util.List;

public interface OrchidXd12Repository extends JpaRepository<OrchidXd12,Long> {
    List<OrchidXd12> findAllByTanggal(Date tanggal);

    OrchidXd12 findByTanggalAndKode(Date tanggal, String code);

    @Query(value = "SELECT * FROM ORCHIDXD12 WHERE tanggal = :date and ( Kode = :code or ReksadanaCode = :code)", nativeQuery = true)
    OrchidXd12 searchDataBy(
            @Param("date") String date,
            @Param("code") String code);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDXD12 WHERE Tanggal = :tgl and ReksadanaCode = :rekCode", nativeQuery = true)
    void deleteOrchidXd12(@Param("tgl") Date tgl,
                          @Param("rekCode") String rekCode);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDXD12 WHERE Tanggal = :tgl", nativeQuery = true)
    void deleteAllOrchidXd12(@Param("tgl") Date tgl);

}
