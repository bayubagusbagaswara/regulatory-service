package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

import javax.persistence.Column;
import java.util.Date;

@Data
public class PUPRecordDTO {
    private Long id;
    private String reksadanaCode;
    private String reksadanaName;
    private Date changesDate;
    private int previousDaysTotal;
    private int daysTotal;
    private int pupTotal;
}
