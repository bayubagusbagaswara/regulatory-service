
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_breach_nilai_pasar_wajar")
public class BreachNilaiPasarWajar {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "reksadana_type")
    private String reksadanaType;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "pf_external_code")
    private String portfolioExternalCode;

    @Column(name = "jumlah_XD14")
    private double jumlahXD14;

    @Column(name = "nilai")
    private double nilai;

    @Column(name = "amortization_price")
    private double amortizationPrice;

    @Column(name = "lower_price")
    private double lowerPrice;

    @Column(name = "today_price")
    private double todayPrice;

    @Column(name = "upper_price")
    private double upperPrice;

    @Column(name = "closing_price")
    private double closingPrice;

    @Column(name = "breach")
    private String breach;
}
