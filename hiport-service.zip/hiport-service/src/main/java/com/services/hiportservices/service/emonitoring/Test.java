package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.repository.emonitoring.OrchidXd14Repository;
import com.services.hiportservices.utils.ConfigPropertiesUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Test {
    static OrchidXd14Repository xd14;
    public static void main(String[] args) {


//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        List<OrchidXd14> listOrchid = new ArrayList<>();

        try {
//            Date dateParm = sdf.parse("2023-07-03");
            String ip = ConfigPropertiesUtil.getProperty("hiport.ip", "connection.properties");
            String ipurs = ConfigPropertiesUtil.getProperty("urs.ip", "connection.properties");
            String x = ConfigPropertiesUtil.getAllValue("xd14.properties");

            System.out.println(ip);
            System.out.println(ipurs);
            System.out.println(x);
//            xd14.findByTanggalAndKode(dateParm,"");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
