package com.services.hiportservices.controller.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd12;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.service.emonitoring.OrchidXd12Service;
import com.services.hiportservices.service.emonitoring.OrchidXd14Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.sound.midi.Soundbank;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd14")
public class OrchidXD14Controller {
    @Autowired
    OrchidXd14Service orchidXd14Service;

    @GetMapping("/updateAndInsert")
    public List<OrchidXd14> updateAndInsertXD14(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf,
            @RequestParam(name = "group", required = false) String group

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);
        System.out.println(group);

        return orchidXd14Service.doProcessEachData(date, pf, group);
    }

    @GetMapping("/getDataXD14")
    public List<OrchidXd14> getDataXD14(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd14Service.getDataXD14(date, pf);
    }
}
