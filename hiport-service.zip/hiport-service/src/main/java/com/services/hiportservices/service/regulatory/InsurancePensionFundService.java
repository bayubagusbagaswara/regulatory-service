package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.insurance.CreateInsuranceListRequest;

/**
 * for maintenance Asuransi dan Dana Pensiun
 */
public interface InsurancePensionFundService {

    // upload list
    String createMultiple(CreateInsuranceListRequest createInsuranceListRequest);

    // approve single

    // edit satuan

    // edit multiple

    // approve single

    // delete single

    // delete approve

    // get single data by id

    // get all data

}
