package com.services.hiportservices.model.compliance;

import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_data_change")
public class ComplianceDataChange extends Approvable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private ChangeAction action;

    @Column(name = "entity_class_name")
    private String entityClassName;

    @Column(name = "entity_id" )
    private String entityId;

    @Column(name = "table_name" )
    private String tableName;

    @Lob
    @Column(name = "data_before")
    private String dataBefore;

    @Lob
    @Column(name = "data_after")
    private String dataChange;

}
