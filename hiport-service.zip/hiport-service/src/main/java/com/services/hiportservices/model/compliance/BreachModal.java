
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_breach_modal_disetor")
public class BreachModal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "issuer")
    private String issuer;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "pf_external_code")
    private String portfolioExternalCode;

    @Column(name = "jumlah_XD14")
    private double jumlahXD14;

    @Column(name = "listed_shares")
    private double listedShares;

    @Column(name = "modal")
    private double modal;

    @Column(name = "breach")
    private String breach;
}
