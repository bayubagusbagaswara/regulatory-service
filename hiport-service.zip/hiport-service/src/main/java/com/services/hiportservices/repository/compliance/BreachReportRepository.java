package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.BreachReport;
import com.services.hiportservices.model.compliance.PUP;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface BreachReportRepository extends JpaRepository<BreachReport,Long> {

    @Query(value="SELECT * FROM comp_breach_report WHERE data_date = :dataDate", nativeQuery = true)
    List<BreachReport> searchAllBreachReportAt (@Param("dataDate") String dataDate);
}
