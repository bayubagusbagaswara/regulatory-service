package com.services.hiportservices.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class DCParentResponseDto {
    private String tableName;
    private List<DataChangeResponseDto> data;
}
