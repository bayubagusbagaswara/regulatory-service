package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "regrep_customer_activity")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerActivity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_number")
    private String idNumber;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "security")
    private String security;

    @Column(name = "trade_type")
    private String tradeType;

    @Column(name = "units")
    private BigDecimal units;

    @Column(name = "unit_price")
    private BigDecimal unitNetPrice;

    @Column(name = "total_expenses")
    private BigDecimal totalExpenses;

    @Column(name = "accrual_interest")
    private BigDecimal accrualInterest; // tidak perlu remove titik, karena otomatis jadi comma

    @Column(name = "settlement_value")
    private BigDecimal settlementValue;

    @Column(name = "settlement_date")
    private LocalDate settlementDate;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "negara_asal")
    private String negaraAsal;

    @Column(name = "isin_code")
    private String isinCode;

    @Column(name = "issuer_code")
    private String issuerCode;

    @Column(name = "code_tipe_ap_1")
    private String codeTipeAP1;

    @Column(name = "code_tipe_ap_2")
    private String codeTipeAP2;

    @Column(name = "currency")
    private String currency;

    @Column(name = "external_code_2")
    private String externalCode2;

    @Column(name = "security_code_lbabk")
    private String securityCodeLBABK;

    @Column(name = "customer_type")
    private String customerType;

    @Column(name = "system")
    private String system;

    @Column(name = "client_status")
    private String clientStatus;

}
