package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "regulatory_issuer_code")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SecuritiesIssuerCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "external_code_2")
    private String externalCode2;

    @Column(name = "currency")
    private String currency;

    @Column(name = "issuer_lbabk")
    private String issuerLBABK;

    @Column(name = "issuer_lkpbu")
    private String issuerLKPBU;

}
