package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.AmortizationPrice;
import com.services.hiportservices.model.compliance.IDXPrice;
import com.services.hiportservices.repository.compliance.AmortizationPriceRepository;
import com.services.hiportservices.repository.compliance.IDXPriceRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class IDXPriceService {

    @Autowired
    IDXPriceRepository idxPriceRepository;

    @Autowired
    EntityManager entityManager;

    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat formatFront = new SimpleDateFormat("yyyy-MM-dd");


    @Transactional
    public ResponseEntity<ResponseDto> insertDataIdxPrice(List<Map<String, String>> idxPriceList) {
        String message = "Input data success!";
        try {
            for (Map<String, String> idxPrice : idxPriceList){
                String date = idxPrice.get("Tanggal Perdagangan Terakhir");
                String[] dateSplit = date.split("\\s+");
                if (dateSplit[1].equalsIgnoreCase("Jan")){
                    date = dateSplit[2]+"01"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Feb")){
                    date = dateSplit[2]+"02"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Mar")){
                    date = dateSplit[2]+"03"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Apr")){
                    date = dateSplit[2]+"04"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Mei")){
                    date = dateSplit[2]+"05"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Jun")){
                    date = dateSplit[2]+"06"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Jul")){
                    date = dateSplit[2]+"07"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Agu")){
                    date = dateSplit[2]+"08"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Sep")){
                    date = dateSplit[2]+"09"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Okt")){
                    date = dateSplit[2]+"10"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Nov")){
                    date = dateSplit[2]+"11"+dateSplit[0];
                } else if (dateSplit[1].equalsIgnoreCase("Des")){
                    date = dateSplit[2]+"12"+dateSplit[0];
                }

                Date dateOfData = format.parse(date);
                String kodeSaham = idxPrice.get("Kode Saham").trim();
                String namaPerusahaan = idxPrice.get("Nama Perusahaan");
                String remarks = idxPrice.get("Remarks");
                double bid = Double.valueOf(idxPrice.get("Bid"));
                double bidVolume = Double.valueOf(idxPrice.get("Bid Volume"));
                double firstTrade = Double.valueOf(idxPrice.get("First Trade"));
                double foreignBuy = Double.valueOf(idxPrice.get("Foreign Buy"));
                double foreignSell = Double.valueOf(idxPrice.get("Foreign Sell"));
                double frekuensi = Double.valueOf(idxPrice.get("Frekuensi"));
                double indexIndividual = Double.valueOf(idxPrice.get("Index Individual"));
                double listedShares = Double.valueOf(idxPrice.get("Listed Shares"));
                double nilai = Double.valueOf(idxPrice.get("Nilai"));
                double nonRegularFrequency = Double.valueOf(idxPrice.get("Non Regular Frequency"));
                double nonRegularValue = Double.valueOf(idxPrice.get("Non Regular Value"));
                double nonRegularVolume = Double.valueOf(idxPrice.get("Non Regular Volume"));
                double offer = Double.valueOf(idxPrice.get("Offer"));
                double offerVolume = Double.valueOf(idxPrice.get("Offer Volume"));
                double openPrice = Double.valueOf(idxPrice.get("Open Price"));
                double penutupan = Double.valueOf(idxPrice.get("Penutupan"));
                double sebelumnya = Double.valueOf(idxPrice.get("Sebelumnya"));
                double selisih = Double.valueOf(idxPrice.get("Selisih"));
                double terendah = Double.valueOf(idxPrice.get("Terendah"));
                double tertinggi = Double.valueOf(idxPrice.get("Tertinggi"));
                double tradebleShares = Double.valueOf(idxPrice.get("Tradeble Shares"));
                double volume = Double.valueOf(idxPrice.get("Volume"));
                double weightForIndex = Double.valueOf(idxPrice.get("Weight For Index"));

                IDXPrice iP = idxPriceRepository.searchByStockCodeAndDate(kodeSaham, dateOfData);
                if (iP == null){
                    idxPriceRepository.insertIntoIdxPrice(UserIdUtil.getUser(), new Date(), dateOfData,
                            kodeSaham, namaPerusahaan, sebelumnya, openPrice, firstTrade, tertinggi, terendah,
                            penutupan,selisih, volume, nilai, frekuensi, indexIndividual, offer, offerVolume, bid,
                            bidVolume, listedShares, tradebleShares, weightForIndex, foreignSell, foreignBuy,
                            nonRegularVolume, nonRegularValue, nonRegularFrequency, remarks);
                }else {
//                    idxPriceRepository.updateIdxPrice(UserIdUtil.getUser(), new Date(),
//                            sebelumnya, openPrice, firstTrade, tertinggi, terendah,
//                            penutupan,selisih, volume, nilai, frekuensi, indexIndividual, offer, offerVolume, bid,
//                            bidVolume, listedShares, tradebleShares, weightForIndex, foreignSell, foreignBuy,
//                            nonRegularVolume, nonRegularValue, nonRegularFrequency, remarks, dateOfData, kodeSaham);
                    iP.setApprovalStatus(ApprovalStatus.Pending);
                    iP.setApproveDate(null);
                    iP.setApproverId(null);
                    iP.setInputerId(UserIdUtil.getUser());
                    iP.setInputDate(new Date());
                    iP.setBid(bid);
                    iP.setBidVolume(bidVolume);
                    iP.setClosingPrice(penutupan);
                    iP.setDifference(selisih);
                    iP.setFirstTrade(firstTrade);
                    iP.setForeignBuy(foreignBuy);
                    iP.setForeignSell(foreignSell);
                    iP.setFrequency(frekuensi);
                    iP.setHighestPrice(tertinggi);
                    iP.setLowestPrice(terendah);
                    iP.setLastPrice(sebelumnya);
                    iP.setIndexIndividual(indexIndividual);
                    iP.setIndexWeight(weightForIndex);
                    iP.setClosingPrice(penutupan);
                    iP.setListedShares(listedShares);
                    iP.setNonRegularFreq(nonRegularFrequency);
                    iP.setNonRegularValue(nonRegularValue);
                    iP.setNonRegularVolume(nonRegularVolume);
                    iP.setOffer(offer);
                    iP.setOfferVolume(offerVolume);
                    iP.setValue(nilai);
                    iP.setVolume(volume);
                    iP.setOpenPrice(openPrice);
                    iP.setTradebleShares(tradebleShares);
                    idxPriceRepository.save(iP);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(message);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findDataAt(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatFront.parse(date);
//            System.out.println(dateOfData);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(idxPriceRepository.searchByDataDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataIDXPrice() {
        List<Map<String, Object>> listPendingDataIdxPrice = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                    "select last_market_date, count(*), inputer_id from comp_idx_price " +
                            "where approval_status = 'Pending' " +
                            "group by last_market_date, inputer_id");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("date", data[0]);
                eachColumn.put("totalData", data[1]);
                eachColumn.put("inputerId", data[2]);

                listPendingDataIdxPrice.add(eachColumn);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(listPendingDataIdxPrice);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataIDXPrice(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        System.out.println(approverId);
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            idxPriceRepository.approveOrRejectIDXPrice("Approved", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataIDXPrice(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            idxPriceRepository.approveOrRejectIDXPrice("Rejected", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> viewPendingData(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatFront.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(idxPriceRepository.searchPendingData(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
