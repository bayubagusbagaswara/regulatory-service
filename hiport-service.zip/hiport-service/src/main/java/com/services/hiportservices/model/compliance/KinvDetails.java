package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_kinv_details")
public class KinvDetails{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name="kinv_code", nullable=false)
    private String kinvCode;

    @Column(name="portfolio_type", nullable=false)
    private int portfolioType;
}
