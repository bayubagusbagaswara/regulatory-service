package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.exchangerate.*;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.mapper.ExchangeRateMapper;
import com.services.hiportservices.model.regulatory.ExchangeRate;
import com.services.hiportservices.repository.regulatory.ExchangeRateRepository;
import com.services.hiportservices.service.regulatory.ExchangeRateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExchangeRateServiceImpl implements ExchangeRateService {

    private final ExchangeRateMapper exchangeRateMapper;
    private final ExchangeRateRepository exchangeRateRepository;

    @Override
    public ExchangeRateResponse createSingleData(CreateExchangeRateRequest createExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Create single data exchange rate with request: {}", createExchangeRateRequest);
        // Validation: semua data wajib diisi. Kita kasih not blank di dto/request nya
        // 1. Currency Code
        // 2. Currency Name
        // 3. Rate Value
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        ExchangeRateDTO exchangeRateDTO = null;

        try {
//        boolean existsByCurrency = exchangeRateRepository.existsByCurrency(createExchangeRateRequest.getCurrency());
//
//        if (existsByCurrency) {
//            throw new BadRequestException("Currency " + createExchangeRateRequest.getCurrency() + " already exist");
//        }
        } catch (Exception e) {

        }

       return new ExchangeRateResponse();
    }

    @Override
    public ExchangeRateResponse createSingleApprove(String approveIPAddress, ExchangeRateApproveRequest exchangeRateApproveRequest) {
        return null;
    }


    @Override
    public ExchangeRateResponse updateSingleData(UpdateExchangeRateRequest updateExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ExchangeRateResponse updateSingleApprove(ExchangeRateApproveRequest exchangeRateApproveRequest, String clientIP) {
        return null;
    }

    @Override
    public ExchangeRateResponse deleteSingleData(DeleteExchangeRateRequest deleteExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public ExchangeRateResponse deleteSingleApprove(ExchangeRateApproveRequest exchangeRateApproveRequest, String clientIP) {
        return null;
    }

    @Override
    public ExchangeRateDTO getById(Long id) {
        return null;
    }

    @Override
    public ExchangeRateDTO getByCurrencyCode(String currencyCode) {
        return null;
    }

    @Override
    public ExchangeRateDTO getByCurrencyName(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findByCurrency(currency)
                .orElseThrow(() -> new DataNotFoundHandleException("Exchange Rate not found with currency: " + currency));
        return exchangeRateMapper.toDTO(exchangeRate);
    }

    @Override
    public List<ExchangeRateDTO> getAll() {
        return null;
    }


}
