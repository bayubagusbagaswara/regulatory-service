package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.CustomerActivity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface CustomerActivityRepository extends JpaRepository<CustomerActivity, Long> {

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM CustomerActivity c WHERE c.month = :month AND c.year = :year")
    void deleteByMonthAndYear(@Param("month") String monthName, @Param("year") Integer yearMinus1);

}
