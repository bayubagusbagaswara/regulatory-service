package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.insurance.CreateInsuranceListRequest;
import com.services.hiportservices.repository.regulatory.InsurancePensionFundRepository;
import com.services.hiportservices.service.regulatory.InsurancePensionFundService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class InsurancePensionFundServiceImpl implements InsurancePensionFundService {

    private final InsurancePensionFundRepository insurancePensionFundRepository;

    @Override
    public String createMultiple(CreateInsuranceListRequest createInsuranceListRequest) {
        return null;
    }

}
