
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_breach_report")
public class BreachReport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "breach_type")
    private String breachType;

    @Column(name = "description")
    private String description;

    @Column(name = "jumlah_before")
    private double jumlahBefore;

    @Column(name = "jumlah_after")
    private double jumlahAfter;

    @Column(name = "aktif_pasif")
    private String aktifPasif;

    @Column(name = "redemption")
    private boolean isRedemption;
}
