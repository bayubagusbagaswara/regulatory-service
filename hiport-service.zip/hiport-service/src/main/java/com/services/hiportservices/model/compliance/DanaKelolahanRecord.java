
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_dana_kelolahan_record")
public class DanaKelolahanRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "breach_started")
    private Date breachStarted;

    @Column(name = "breach_ended")
    private Date breachEnded;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "changes_date")
    private Date changesDate;

    @Column(name = "previous_days_total")
    private int previousDaysTotal;

    @Column(name = "days_total")
    private int daysTotal;

    @Column(name = "jumlah_dana")
    private double jumlahDana;

    @Column(name = "previous_jumlah_dana")
    private double previousJumlahDana;

}
