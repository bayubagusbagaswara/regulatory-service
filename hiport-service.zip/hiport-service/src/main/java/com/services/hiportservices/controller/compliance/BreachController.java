package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.BreachService;
import com.services.hiportservices.service.compliance.PUPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/breach")
public class BreachController {

    @Autowired
    BreachService breachService;

    @GetMapping("/checkPortfolio/{date}")
    public ResponseEntity<ResponseDto> checkPortfolio(@PathVariable String date) {
        return breachService.checkPortfolio(date);
    }

    @GetMapping("/checkMapping/{date}")
    public ResponseEntity<ResponseDto> checkMappingPortfolio(@PathVariable String date) {
        return breachService.checkMappingPortfolio(date);
    }

    @GetMapping("/process")
    public ResponseEntity<ResponseDto> processCompliaceReport(@RequestParam String date,
                                                              @RequestParam String action) {
        return breachService.processComplianceReport(date, action);
    }

    @GetMapping("/report")
    public ResponseEntity<ResponseDto> getBreachReport(@RequestParam String date,
                                                       @RequestParam String action) {
        return breachService.getBreachReport(date, action);
    }




}
