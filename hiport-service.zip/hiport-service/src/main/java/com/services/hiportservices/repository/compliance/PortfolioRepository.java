package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.compliance.PortfolioType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface PortfolioRepository extends JpaRepository<Portfolio,Long> {
    Portfolio findByCode(String code);

    @Query("SELECT u FROM Portfolio u WHERE u.approvalStatus = :approvalStatus and u.code like %:code% and u.delete = false")
    List<Portfolio> searchByCodeLike(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("code") String code);

    @Query("SELECT u FROM Portfolio u WHERE u.approvalStatus = :approvalStatus and u.externalCode like %:externalCode% and u.delete = false")
    List<Portfolio> searchByExternalCodeLike(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("externalCode") String extCode);

    List<Portfolio> findAllByDeleteAndApprovalStatus(boolean isDelete, ApprovalStatus approvalStatus);

    @Query("SELECT u FROM Portfolio u WHERE  u.approvalStatus = 'Pending' and u.delete = false")
    List<Portfolio> searchPendingPortfolioData();

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_portfolio SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE code = :code", nativeQuery = true)
    void approveOrRejectPortfolio(@Param("approvalStatus") String approvalStatus,
                                      @Param("approveDate") Date approveDate,
                                      @Param("approverId") String approverId,
                                      @Param("code") String code);
}
