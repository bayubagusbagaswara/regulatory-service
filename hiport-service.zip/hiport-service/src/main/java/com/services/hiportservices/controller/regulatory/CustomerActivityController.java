package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.regulatory.CustomerActivityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/customer-activity")
@Slf4j
@RequiredArgsConstructor
public class CustomerActivityController {

    private final CustomerActivityService customerActivityService;

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDto<String>> readAndInsertToDB() {
        String status = customerActivityService.readAndInsertToDB();
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

}
