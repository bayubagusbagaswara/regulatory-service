package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

import java.util.Date;

@Data
public class BreachReportRequestDTO {
    private Long id;
    private Date date;
    private String reksadanaCode;
    private String rdExternalCode;
    private String breachType;
    private String description;
    private double jumlahBefore;
    private double jumlahAfter;
    private String aktifPasif;
    private boolean isRedemption;
}
