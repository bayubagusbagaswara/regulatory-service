
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_breach_type")
public class BreachRdTypeAndSecType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "reksadana_type")
    private String reksadanaType;

    @Column(name = "portfolio_type")
    private String portfolioType;

    @Column(name = "jumlah_XD14")
    private double jumlahXD14;

    @Column(name = "breach")
    private String breach;
}
