package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.repository.regulatory.IssuerCodeRepository;
import com.services.hiportservices.service.regulatory.ISSUERCodeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ISSUERCodeServiceImpl implements ISSUERCodeService {

    // inject repository issuer code
    private final IssuerCodeRepository issuerCodeRepository;

    // method check apakah ada di database

    @Override
    public void getISSUERCode(String issuerCode) {
        Boolean aBoolean = issuerCodeRepository.existsByIssuerCode(issuerCode);

        // jika true, maka issuerCode ada di table database
        // jika false, maka issuerCode tidak ada di table database
    }

}
