package com.services.hiportservices.dto.regulatory;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegulatoryDataChangeDTO {

    private Long id;

    private ApprovalStatus approvalStatus;

    private String inputerId;

    private LocalDateTime inputDate;

    private String inputIPAddress;

    private String approverId;

    private LocalDateTime approveDate;

    private String approveIPAddress;

    private ChangeAction action;

    private String entityClassName;

    private String entityId;

    private String tableName;

    private String jsonDataBefore;

    private String jsonDataAfter;

    private String description;

    private String methodHttp;

    private String endpoint;

    private boolean isRequestBody;

    private boolean isRequestParam;

    private boolean isPathVariable;

    private String menu;

    public RegulatoryDataChangeDTO(String inputIPAddress, String methodHttp, String endpoint, boolean isRequestBody, boolean isRequestParam, boolean isPathVariable, String menu) {
        this.inputIPAddress = inputIPAddress;
        this.methodHttp = methodHttp;
        this.endpoint = endpoint;
        this.isRequestBody = isRequestBody;
        this.isRequestParam = isRequestParam;
        this.isPathVariable = isPathVariable;
        this.menu = menu;
    }

}
