package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd13;
import com.services.hiportservices.repository.emonitoring.OrchidXd11Repository;
import com.services.hiportservices.repository.emonitoring.OrchidXd13Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;

@Service
public class OrchidXd13Service {
    @Autowired
    OrchidXd13Repository orchidXd13Repository;

    public List<OrchidXd13> getDataXD13(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd13> listOrchid = new ArrayList<>();

        try {
            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {

                listOrchid.addAll(orchidXd13Repository.findAllByTanggal(dateParm));
                System.out.println(listOrchid.size());

            } else {
                listOrchid.add(orchidXd13Repository.searchDataBy(date, pfCode));

                System.out.println(listOrchid.size());
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
