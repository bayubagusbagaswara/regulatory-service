package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.lbabk.LBABKDTO;
import com.services.hiportservices.model.regulatory.LBABKCustomerActivity;

import java.util.List;

public interface LBABKService {

    List<LBABKDTO> getAllDataMock();

    List<LBABKCustomerActivity> getAllForSheet1(String monthYear);

    List<LBABKCustomerActivity> getAllForSheet2(String monthYear);
}
