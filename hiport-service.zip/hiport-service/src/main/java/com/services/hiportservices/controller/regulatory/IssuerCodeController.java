package com.services.hiportservices.controller.regulatory;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/regulatory/issuer")
public class IssuerCodeController {
}
