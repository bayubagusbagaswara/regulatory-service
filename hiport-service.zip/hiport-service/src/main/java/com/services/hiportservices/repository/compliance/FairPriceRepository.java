package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Repository
public interface FairPriceRepository extends JpaRepository<FairPrice,Long> {
    @Query("SELECT u FROM FairPrice u WHERE u.securityCode = :securityCode and u.date = :date")
    FairPrice searchBySecCodeAndDate(
            @Param("securityCode") String securityCode,
            @Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value="INSERT INTO comp_fair_price (approval_status, inputer_id, input_date, data_date, security_code, security_desc, lower_price, today_price, upper_price, stdev)"
            + " VALUES ('Pending', :inputerId, :inputDate, :dataDate, :securityCode, :securityDesc, :lowerPrice, :todayPrice, :upperPrice, :stdev)", nativeQuery = true)
    void insertIntoFairPrice(@Param("inputerId") String inputerId,
                       @Param("inputDate") Date inputDate,
                       @Param("dataDate") Date dataDate,
                       @Param("securityCode") String securityCode,
                       @Param("securityDesc") String securityDesc,
                       @Param("lowerPrice") double lowerPrice,
                       @Param("todayPrice") double todayPrice,
                       @Param("upperPrice") double upperPrice,
                       @Param("stdev") double stdev);

    @Query("SELECT u FROM FairPrice u WHERE u.date = :date and u.approvalStatus = 'Approved'")
    List<FairPrice> searchApproveData(@Param("date") Date date);

    @Query("SELECT u FROM FairPrice u WHERE u.date = :date and u.approvalStatus = 'Pending'")
    List<FairPrice> searchPendingData(@Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_fair_price SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverrId " +
            "WHERE data_date = :dataDate", nativeQuery = true)
    void approveOrRejectFairPrice(@Param("approvalStatus") String approvalStatus,
                          @Param("approveDate") Date approveDate,
                          @Param("approverrId") String approverrId,
                          @Param("dataDate") String dataDate);


}
