package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.AddDeletePortfolioKINVRequestDTO;
import com.services.hiportservices.dto.request.compliance.MappingKINVRequestDTO;
import com.services.hiportservices.model.compliance.PortfolioKINVGrouping;
import com.services.hiportservices.service.compliance.PortfolioKINVGroupingService;
import com.services.hiportservices.service.compliance.ReksadanaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/portfolioKINV")
public class PortfolioKINVGroupingController {
    @Autowired
    PortfolioKINVGroupingService portfolioKINVGroupingService;

    @PostMapping
    public ResponseEntity<ResponseDto> save(@RequestBody AddDeletePortfolioKINVRequestDTO addDeletePortfolioKINVRequestDTO)  {
        return portfolioKINVGroupingService.insertMappingPortfolioKinv(addDeletePortfolioKINVRequestDTO);
    }

    @PutMapping("/upload/{param}")
    public ResponseEntity<ResponseDto> uploadFileMappingPortfolio(@PathVariable String param, @RequestBody List<Map<String, String>> portfolioMappingList) {
        return portfolioKINVGroupingService.insertMappingPortfolioUpload(param, portfolioMappingList);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> searchPortfolio(@RequestParam String reksadanaCode)  {
        return portfolioKINVGroupingService.findByReksadanaCode(reksadanaCode);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return portfolioKINVGroupingService.allPendingDataMapping();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return portfolioKINVGroupingService.approveDataMapping(codeList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return portfolioKINVGroupingService.rejectDataMapping(codeList);
    }

//    @GetMapping("/{code}")
//    public ResponseEntity<ResponseDto> getByCode(@PathVariable String code)  {
//        return reksadanaService.getByCode(code);
//    }
//
//    @PutMapping("/delete/{code}")
//    public ResponseEntity<ResponseDto> deleteById(@PathVariable String code)  {
//        return reksadanaService.deleteByCode(code);
//    }
}
