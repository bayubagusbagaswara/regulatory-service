package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "REGREPLKPBUVALTB")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegrepLKPBUValTb {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Temporal(TemporalType.DATE)
    @Column(name = "PROCESSDATE")
    private Date processDate;

    @Column(name = "PORTFOLIOCODE")
    private String portfolioCode;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "PORTFOLIONAME")
    private String portfolioName;

    @Column(name = "SECURITYCODE")
    private String securityCode;

    @Column(name = "EXTERNALCODE")
    private String externalCode;

    @Column(name = "SECURITYCCY")
    private String securityCcy;

    @Column(name = "SECURITYNAME")
    private String securityName;

    @Column(name = "UNITS", precision = 18, scale = 2)
    private BigDecimal units; // numeric

    @Column(name = "MARKETVALUE", precision = 18, scale = 2)
    private BigDecimal marketValue; // numeric

    @Temporal(TemporalType.DATE)
    @Column(name = "ISSUEDATE")
    private Date issueDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "MATURITYDATE")
    private Date maturityDate;

    @Column(name = "GOLPEMILIK")
    private String golPemilik;

    @Column(name = "NEGARAPEMILIK")
    private String negaraPemilik;

    @Column(name = "GOLPENERBIT")
    private String golPenerbit;

    @Column(name = "NEGARAPENERBIT")
    private String negaraPenerbit;

    @Column(name = "JENISSECURITY")
    private String jenisSecurity;

}
