package com.services.hiportservices.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.services.hiportservices.dto.request.emonitoring.Xd14RequestDto;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.repository.compliance.MasterKebijakanInvestasiRepository;
import com.services.hiportservices.repository.emonitoring.OrchidXd11Repository;
import com.services.hiportservices.repository.emonitoring.OrchidXd14Repository;
import com.services.hiportservices.service.*;
import com.services.hiportservices.service.compliance.PortfolioTypeService;
import com.services.hiportservices.service.emonitoring.OrchidXd11Service;
import com.services.hiportservices.service.emonitoring.OrchidXd14Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.sql.*;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/v1")
public class MasterController {
    @Autowired
    PortfolioTypeService portfolioTypeService;
    @Autowired
    MasterKebijakanInvestasiRepository masterKebijakanInvestasiRepository;
    @Autowired
    SecurityMasterService securityMasterService;
    @Autowired
    AccountService accountService;
    @Autowired
    FundMasterService fundMasterService;
    @Autowired
    ExpenseService expenseService;
    @Autowired
    S4Service s4Service;
    @Autowired
    CifService cifService;
    @Autowired
    Bis4NonRetailService bis4NonRetailService;
    @Autowired
    ShowMediaFileService showMediaFileService;
    @Autowired
    OrchidXd14Repository orchidXd14Repository;
    @Autowired
    OrchidXd11Repository orchidXd11Repository;
    @Autowired
    OrchidXd14Service orchidXd14Service;

    @Autowired
    OrchidXd11Service orchidXd11Service;
    Logger logger = LoggerFactory.getLogger(MasterController.class);


    @PutMapping("/expense")
    public ResponseEntity<ResponseDto> updateExpense() throws SQLException, ClassNotFoundException {
        logger.info("update Expense");
        return expenseService.updateExpense();
    }

    @PutMapping("/account")
    public ResponseEntity<ResponseDto> updateAccount() throws SQLException, ClassNotFoundException {
        logger.info("update account");
        return accountService.update();
    }

    @PutMapping("/S4")
    public ResponseEntity<ResponseDto> updateS4() {
        logger.info(("Update S4"));
        return s4Service.updateS4();
    }

    @PutMapping("/cif/{id}")
    public ResponseEntity<ResponseDto> updateCif(@PathVariable String id) {
        logger.info("update account");
        return cifService.updateCif(id);
    }

    @PutMapping("/bis4nonretail")
    public ResponseEntity<ResponseDto> updateBis4NonRtl() {

        logger.info("update account");
        return bis4NonRetailService.updateBis4NonRtl();
    }

    @PutMapping("/showMediaFile")
    public ResponseEntity<ResponseDto> updateShowMediaFl() {
        logger.info("update account");
        return showMediaFileService.updateShowMediaFile();
    }


    @PutMapping("/security")
    public ResponseEntity<ResponseDto> updateSecurityMaster() throws SQLException, ClassNotFoundException {
        logger.info("update account");
        return securityMasterService.getSecurityMaster();
    }

    @PutMapping("/fundmaster")
    public ResponseEntity<ResponseDto> updatefundMaster() throws SQLException, ClassNotFoundException {
        logger.info("update fundMaster");
        return fundMasterService.updateFunMaster();
    }


}

