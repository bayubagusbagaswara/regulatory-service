package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.BreachIssuer;
import com.services.hiportservices.model.compliance.BreachReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BreachIssuerRepository extends JpaRepository<BreachIssuer,Long> {

    @Query(value="SELECT * FROM comp_breach_issuer WHERE data_date = :dataDate", nativeQuery = true)
    List<BreachIssuer> searchDataAt(@Param("dataDate") String dataDate);
}
