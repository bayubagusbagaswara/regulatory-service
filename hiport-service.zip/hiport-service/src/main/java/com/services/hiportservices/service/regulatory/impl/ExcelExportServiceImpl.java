package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUDTO;
import com.services.hiportservices.service.regulatory.ExcelExportService;
import com.services.hiportservices.service.regulatory.LBABKService;
import com.services.hiportservices.service.regulatory.LKPBUService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExcelExportServiceImpl implements ExcelExportService {

    private final LKPBUService lkpbuService;
    private final LBABKService lbabkService;

    @Override
    public ByteArrayInputStream exportToExcel() throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            // Sheet 1 untuk data LKPBU
            Sheet sheet1 = workbook.createSheet("LKPBU");
            List<LKPBUDTO> lkpbudtoList = lkpbuService.getAllDataMock();
            writeLKPBUToSheet(workbook, sheet1, lkpbudtoList);

            // Sheet 2


            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    // get data LKPBU, then set to sheet 1
    private void writeLKPBUToSheet(Workbook workbook, Sheet sheet, List<LKPBUDTO> lkpbudtoList) {
        // Buat CellStyle untuk header
        CellStyle headerCellStyle = createHeaderCellStyleForegroundIsYellow(workbook);

        // Mengatur lebar kolom
        sheet.setColumnWidth(1, 3000); // Mengatur lebar kolom untuk kolom B
        sheet.setColumnWidth(2, 5000); // Mengatur lebar kolom untuk kolom C
        sheet.setColumnWidth(3, 5000); // Mengatur lebar kolom untuk kolom D
        sheet.setColumnWidth(4, 5000);
        sheet.setColumnWidth(5, 5000);
        sheet.setColumnWidth(6, 5000);
        sheet.setColumnWidth(7, 5000);
        sheet.setColumnWidth(8, 5000);
        sheet.setColumnWidth(9, 5000);
        sheet.setColumnWidth(10, 5000);
        sheet.setColumnWidth(11, 5000);
        sheet.setColumnWidth(12, 5000);
        sheet.setColumnWidth(13, 5000);
        sheet.setColumnWidth(14, 5000);

        // Header baris kedua
        Row headerRow2 = sheet.createRow(0);
        createHeaderCell(headerRow2, 0, "Table 3 Laporan Berkala Terkait Pelaksanaan Aktivitas Sebagai BankCode Kustodian", null);

        // header bari ketiga, untuk merge cell nya
        Row headerRow3 = sheet.createRow(2);

        CellRangeAddress rangeBeli = new CellRangeAddress(2, 2, 7, 10);
        sheet.addMergedRegion(rangeBeli);
        Cell mergedCellBeli = headerRow3.createCell(7);
        mergedCellBeli.setCellValue("Penyelesaian Transaksi Beli");
        mergedCellBeli.setCellStyle(headerCellStyle);
//        ExcelUtil.addBorderToMergedRegion(sheet, rangeBeli);

        CellRangeAddress rangeJual = new CellRangeAddress(2, 2, 11, 14);
        sheet.addMergedRegion(rangeJual);
        Cell cell1 = headerRow3.createCell(11);
        cell1.setCellValue("Penyelesaian Transaksi Jual");
        cell1.setCellStyle(headerCellStyle);
//        ExcelUtil.addBorderToMergedRegion(sheet, rangeJual);


        // Header baris keempat (INI ADALAH NAME HEADER NYA)
        Row headerRow4 = sheet.createRow(3);

        createHeaderCell(headerRow4, 1,"Flag Detail", headerCellStyle);
        createHeaderCell(headerRow4, 2, "Kode Komponen", headerCellStyle);
        createHeaderCell(headerRow4, 3, "Golongan", headerCellStyle);
        createHeaderCell(headerRow4, 4, "Sandi Perusahaan Asuransi/Reasuransi/Dana Pensiun *)", headerCellStyle);
        createHeaderCell(headerRow4, 5, "Nama Perusahaan Asuransi/Reasuransi/Dana Pensiun *)", headerCellStyle);
        createHeaderCell(headerRow4, 6, "Kode Efek", headerCellStyle);
        createHeaderCell(headerRow4, 7, "Penyelesaian Transaksi Beli - Frekuensi", headerCellStyle);
        createHeaderCell(headerRow4, 8, "Penyelesaian Transaksi Beli - Volume", headerCellStyle);
        createHeaderCell(headerRow4, 9, "Penyelesaian Transaksi Beli - Nilai", headerCellStyle);
        createHeaderCell(headerRow4, 10, "Penyelesaian Transaksi Beli - Investor Indonesia", headerCellStyle);
        createHeaderCell(headerRow4, 11, "Penyelesaian Transaksi Jual - Frekuensi", headerCellStyle);
        createHeaderCell(headerRow4, 12, "Penyelesaian Transaksi Jual - Volume", headerCellStyle);
        createHeaderCell(headerRow4, 13, "Penyelesaian Transaksi Jual - Nilai", headerCellStyle);
        createHeaderCell(headerRow4, 14, "Penyelesaian Transaksi Jual - Investor Indonesia", headerCellStyle);

        // Data rows (INI ADALAH DATA, DIISI DIBAWAH HEADER NYA)
        int rowIdx = 4; // Dimulai dari baris ke-4
        for (LKPBUDTO dto : lkpbudtoList) {
            Row row = sheet.createRow(rowIdx++);

            row.createCell(1).setCellValue(dto.getFlagDetail());
            row.createCell(2).setCellValue(dto.getComponentCode());
            row.createCell(3).setCellValue(dto.getGroup());
            row.createCell(4).setCellValue(dto.getCompanyCode());
            row.createCell(5).setCellValue(dto.getCompanyName());
            row.createCell(6).setCellValue(dto.getEffectCode());
            row.createCell(7).setCellValue(dto.getSettlementTransactionBuyFrequency());
            row.createCell(8).setCellValue(dto.getSettlementTransactionBuyVolume().toString());
            row.createCell(9).setCellValue(dto.getSettlementTransactionBuyAmount().toString());
            row.createCell(10).setCellValue(dto.getSettlementTransactionBuyInvestorIndonesia().toString());
            row.createCell(11).setCellValue(dto.getSettlementTransactionSellFrequency());
            row.createCell(12).setCellValue(dto.getSettlementTransactionSellVolume().toString());
            row.createCell(13).setCellValue(dto.getSettlementTransactionSellAmount().toString());
            row.createCell(14).setCellValue(dto.getSettlementTransactionSellInvestorIndonesia().toString());
        }
    }

    private void createHeaderCell(Row row, int column, String value, CellStyle style) {
        Cell cell = row.createCell(column);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }

    private CellStyle createHeaderCellStyleForegroundIsYellow(Workbook workbook) {
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(IndexedColors.CORNFLOWER_BLUE.index);
        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        Font headerFont = workbook.createFont();
//        headerFont.setBold(true);

        headerFont.setColor(IndexedColors.BLACK.getIndex());
        headerFont.setFontHeightInPoints((short) 9); // Mengatur ukuran font menjadi 9
        headerFont.setFontName("Aptos Narrow");
        headerCellStyle.setFont(headerFont);

        headerCellStyle.setWrapText(true);
        headerCellStyle.setVerticalAlignment(VerticalAlignment.TOP); // vertical
        headerCellStyle.setAlignment(HorizontalAlignment.CENTER); // horizontal

        // Mengatur border
        headerCellStyle.setBorderTop(BorderStyle.THIN);
        headerCellStyle.setBorderBottom(BorderStyle.THIN);
        headerCellStyle.setBorderLeft(BorderStyle.THIN);
        headerCellStyle.setBorderRight(BorderStyle.THIN);

        // Mengatur warna border
        headerCellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
        headerCellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        headerCellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());

        return headerCellStyle;
    }

}
