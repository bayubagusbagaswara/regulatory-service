package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LBABKAssetUnderCustody;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LBABKAssetUnderCustodyRepository extends JpaRepository<LBABKAssetUnderCustody, Long> {
}
