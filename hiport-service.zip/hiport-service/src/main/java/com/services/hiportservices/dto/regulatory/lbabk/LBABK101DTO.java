package com.services.hiportservices.dto.regulatory.lbabk;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class LBABK101DTO {

    private String flagDetail;

    private String kodeKomponen;

    private String tanggalTransaksi;

    private String kodeJenisEfek;

    private String keteranganJenisEfek;

    private String kodeISIN;

    private String kodeEfek;

    private String namaEfek;

    private String kodeIssuer;

    private String namaIssuer;

    private String kodeMataUang;

    private String settlementTransactionBuyFrequency;
    private String settlementTransactionBuyVolume;
    private String settlementTransactionBuyValue;
    private String settlementTransactionBuyInvestorIndonesia;
    private String settlementTransactionBuyInvestorForeign;
    private String settlementTransactionBuyTimelyInvestorConfirmation;

    private String settlementTransactionSellFrequency;
    private String settlementTransactionSellVolume;
    private String settlementTransactionSellValue;
    private String settlementTransactionSellInvestorIndonesia;
    private String settlementTransactionSellInvestorForeign;
    private String settlementTransactionSellTimelyInvestorConfirmation;

}
