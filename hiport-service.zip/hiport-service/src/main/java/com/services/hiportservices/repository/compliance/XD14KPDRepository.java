package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.NabKPD;
import com.services.hiportservices.model.compliance.XD14KPD;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

public interface XD14KPDRepository extends JpaRepository<XD14KPD, Long> {


    @Query(value = "SELECT * FROM comp_xd14_kpd  WHERE Tanggal = :date and approval_status = 'Pending'", nativeQuery = true)
    List<XD14KPD> searchPendingXd14KpdDataByDate(@Param("date") Date date);

    @Query(value = "SELECT * FROM comp_xd14_kpd  WHERE Tanggal = :date and approval_status = 'Approved'", nativeQuery = true)
    List<XD14KPD> searchApproveXd14KpdDataByDate(@Param("date") Date date);

    @Query(value = "SELECT * FROM comp_xd14_kpd  WHERE Tanggal = :date and approval_status = 'Approved'", nativeQuery = true)
    List<XD14KPD> searchAllXd14KpdDataByDate(@Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value = "UPDATE comp_xd14_kpd SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE Tanggal = :dataDate", nativeQuery = true)
    void approveOrRejectXD14KPD(@Param("approvalStatus") String approvalStatus,
                                @Param("approveDate") Date approveDate,
                                @Param("approverId") String approverId,
                                @Param("dataDate") String dataDate);

    @Query(value = "SELECT * FROM comp_xd14_kpd WHERE Tanggal = :date and Kode = :code ", nativeQuery = true)
    List<XD14KPD> searchDataAt(
            @Param("date") Date date,
            @Param("code") String reksadancodeaCode);

    @Transactional
    @Modifying
    @Query(value = "DELETE comp_xd14_kpd WHERE Tanggal = :tgl and Kode = :rekCode", nativeQuery = true)
    void deleteXd14(@Param("tgl") Date tgl,
                          @Param("rekCode") String rekCode);




}
