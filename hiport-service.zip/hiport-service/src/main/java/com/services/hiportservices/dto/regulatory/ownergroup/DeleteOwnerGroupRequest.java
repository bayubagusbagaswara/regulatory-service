package com.services.hiportservices.dto.regulatory.ownergroup;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteOwnerGroupRequest extends InputIdentifierRequest {

    private Long id;

}
