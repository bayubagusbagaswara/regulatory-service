package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class Bis4NonRetailService {
    public ResponseEntity<ResponseDto> updateBis4NonRtl(){
        return ResponseEntity.ok(new ResponseDto().builder().code(HttpStatus.OK.toString()).message("Berhasil update data S4").payload("").build());
    }
}
