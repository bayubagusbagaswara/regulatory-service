package com.services.hiportservices.enums;

public enum ApprovalStatus {
	Pending, Approved, Rejected, Canceled, Deleted
}
