package com.services.hiportservices.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponseFundMasterDto {
    private String pfCode;
    private String userDefinedField28;
    private String userDefinedField29;
    private String userDefinedField30;
    private String longName;
}
