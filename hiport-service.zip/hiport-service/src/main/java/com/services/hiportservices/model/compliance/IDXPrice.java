package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_idx_price")
public class IDXPrice extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "last_market_date")
    private Date lastMarketDate;

    @Column(name = "stock_code")
    private String stockCode;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "last_price")
    private double lastPrice;

    @Column(name = "open_price")
    private double openPrice;

    @Column(name = "first_trade")
    private double firstTrade;

    @Column(name = "highest_price")
    private double highestPrice;

    @Column(name = "lowest_price")
    private double lowestPrice;

    @Column(name = "closing_price")
    private double closingPrice;

    @Column(name = "difference")
    private double difference;

    @Column(name = "volume")
    private double volume;

    @Column(name = "the_value")
    private double value;

    @Column(name = "frequency")
    private double frequency;

    @Column(name = "index_individual")
    private double indexIndividual;

    @Column(name = "offer")
    private double offer;

    @Column(name = "offer_volume")
    private double offerVolume;

    @Column(name = "bid")
    private double bid;

    @Column(name = "bid_volume")
    private double bidVolume;

    @Column(name = "listed_shares")
    private double listedShares;

    @Column(name = "tradeble_shares")
    private double tradebleShares;

    @Column(name = "index_weight")
    private double indexWeight;

    @Column(name = "foreign_sell")
    private double foreignSell;

    @Column(name = "foreign_buy")
    private double foreignBuy;

    @Column(name = "non_regular_volume")
    private double nonRegularVolume;

    @Column(name = "non_regular_value")
    private double nonRegularValue;

    @Column(name = "non_regular_freq")
    private double nonRegularFreq;

    @Column(name = "remarks")
    private String remarks;
}
