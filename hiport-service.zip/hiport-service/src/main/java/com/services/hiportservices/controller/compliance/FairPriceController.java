package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.FairPriceService;
import com.services.hiportservices.service.compliance.PUPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/fairPrice")
public class FairPriceController {

    @Autowired
    FairPriceService fairPriceService;

    @PutMapping("/upload")
    public ResponseEntity<ResponseDto> uploadFileFairPrice(@RequestBody List<Map<String, String>> fairPriceList) {
        return fairPriceService.insertDataFairPrice(fairPriceList);
    }

    @GetMapping("/{date}")
    public ResponseEntity<ResponseDto> getAllDataAt(@PathVariable String date) {
        return fairPriceService.findDataAt(date);
    }

    @GetMapping("/viewPending/{date}")
    public ResponseEntity<ResponseDto> viewPendingData(@PathVariable String date) {
        return fairPriceService.viewPendingData(date);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return fairPriceService.allPendingDataFairPrice();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataAt(@RequestBody Map<String, List<String>> dates) {
        return fairPriceService.approveDataFairPrice(dates);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataAt(@RequestBody Map<String, List<String>> dates) {
        return fairPriceService.rejectDataFairPrice(dates);
    }

}
