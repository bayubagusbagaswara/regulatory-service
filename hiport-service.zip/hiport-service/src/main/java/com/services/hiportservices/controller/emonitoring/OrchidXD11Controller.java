package com.services.hiportservices.controller.emonitoring;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.service.emonitoring.OrchidXd11Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd11")
public class OrchidXD11Controller {
    @Autowired
    OrchidXd11Service orchidXd11Service;
    Logger logger = LoggerFactory.getLogger(OrchidXD11Controller.class);

    @GetMapping("/updateAndInsertAsync")
    public CompletableFuture<List<OrchidXd11>> getXd11(
            @RequestParam(name = "date") String date,
            @RequestParam(name = "portfolio", required = false) String pf,
            @RequestParam(name = "group", required = false) String group
    ) throws JsonProcessingException, ClassNotFoundException, SQLException, InterruptedException {
        CompletableFuture<List<OrchidXd11>> future = (CompletableFuture<List<OrchidXd11>>) orchidXd11Service.insertOrUpdateAllAsync(date, pf, group);
        return future.thenApply(result -> {
            if (result != null && !result.isEmpty()) {
                // Jika hasilnya tidak kosong, kembalikan hasilnya
                return result;
            } else {
                // Jika hasilnya kosong, kembalikan pesan atau respons lain
                return Collections.emptyList(); // Misalnya, mengembalikan list kosong
            }
        });
    }

    @GetMapping("/updateAndInsert")
    public List<OrchidXd11> getXd11List(
            @RequestParam(name = "date") String date,
            @RequestParam(name = "portfolio", required = false) String pf,
            @RequestParam(name = "group", required = false) String group

    )
            throws JsonProcessingException, ClassNotFoundException, SQLException, InterruptedException, IOException {
        System.out.println(date);
        System.out.println(pf);
        System.out.println(group);
        return orchidXd11Service.insertOrUpdateAll(date, pf, group);
    }

    @GetMapping("/getDataXD11")
    public List<OrchidXd11> getDataXD11(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd11Service.getDataXD11(date, pf);
    }
}
