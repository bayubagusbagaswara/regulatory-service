package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

@Entity
@Data
@Table(name = "ORCHIDXD11")
public class OrchidXd11 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_xd11")
    private Long id;

    @Column(name = "Kode")
    private String kode;

    @Column(name = "DATE_PROC")
    @Getter(AccessLevel.NONE)
    private Date dateProc;

    @Transient
    @Getter(AccessLevel.NONE)
    private String dateProcStr;

    @Column(name = "STAT_PROC")
    private String statProc;

    @Column(name = "Tanggal")
    @Getter(AccessLevel.NONE)
    private Date tanggal;

    @Transient
    @Getter(AccessLevel.NONE)
    private String tanggalStr;

    @Column(name = "InvUang")
    private BigDecimal invUang = BigDecimal.ZERO;

    @Column(name = "InvHutang")
    private BigDecimal invHutang = BigDecimal.ZERO;

    @Column(name = "InvSaham")
    private BigDecimal invSaham = BigDecimal.ZERO;

    @Column(name = "InvWarran")
    private BigDecimal invWarran = BigDecimal.ZERO;

    @Column(name = "Kas")
    private BigDecimal kas = BigDecimal.ZERO;

    @Column(name = "PDividend")
    private BigDecimal pDividend = BigDecimal.ZERO;

    @Column(name = "PBunga")
    private BigDecimal pBunga = BigDecimal.ZERO;

    @Column(name = "PEfek")
    private BigDecimal pEfek = BigDecimal.ZERO;

    @Column(name = "Plain")
    private BigDecimal plain = BigDecimal.ZERO;

    @Column(name = "ALain")
    private BigDecimal aLain = BigDecimal.ZERO;

    @Column(name = "TAKTIVA")
    private BigDecimal taktiva = BigDecimal.ZERO;

    @Column(name = "UFek")
    private BigDecimal ufek = BigDecimal.ZERO;

    @Column(name = "ULain")//ToTSHM
    private BigDecimal uLain = BigDecimal.ZERO;

    @Column(name = "TKEWAJIBAN")
    private BigDecimal tkewajiban = BigDecimal.ZERO;

    @Column(name = "TABERSIH")//kurang
    private BigDecimal tAbersih = BigDecimal.ZERO;

    @Column(name = "JmlPenyertaan")
    private BigDecimal jmlPenyertaan = BigDecimal.ZERO;

    @Column(name = "Pelunasan")
    private BigDecimal pelunasan = BigDecimal.ZERO;

    @Column(name = "Akumulasi")
    private BigDecimal akumulasi = BigDecimal.ZERO;

    @Column(name = "Pendapatan")
    private BigDecimal pendapatan = BigDecimal.ZERO;

    @Column(name = "LRUnreal")
    private BigDecimal lrUnreal = BigDecimal.ZERO;

    @Column(name = "LRReal")
    private BigDecimal lrRreal = BigDecimal.ZERO;

    @Column(name = "PInvest")
    private BigDecimal pInvest = BigDecimal.ZERO;

    @Column(name = "T_SAHAM_LR")
    private BigDecimal tSahamLr = BigDecimal.ZERO;

    @Column(name = "JumlahUnit")
    private BigDecimal jumlahUnit;

    @Column(name = "NAV")
    private BigDecimal nav = BigDecimal.ZERO;

    @Column(name = "Notes")
    private BigDecimal notes = BigDecimal.ZERO;

    @Column(name = "ReksadanaCode")
    private String reksadanaCode = "";

    public String getTanggalStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(tanggal);
    }

    public String getDateProcStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(dateProc);
    }
}
