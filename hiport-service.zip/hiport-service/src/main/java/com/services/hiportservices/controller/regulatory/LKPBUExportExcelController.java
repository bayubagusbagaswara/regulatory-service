package com.services.hiportservices.controller.regulatory;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;

@RestController
@RequestMapping(path = "/api/regulatory/lkpbu")
@Slf4j
@RequiredArgsConstructor
public class LKPBUExportExcelController {

//    private final LKPBUExportExcelService lkpbuExportExcelService;
//    private final LKPBUExportExcelV2Service lkpbuExportExcelV2Service;

//    @GetMapping("/download")
//    public ResponseEntity<InputStreamResource> downloadExcel() throws Exception {
//        ByteArrayInputStream byteArrayInputStream = lkpbuExportExcelV2Service.exportLKBPUToExcel();
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Content-Disposition", "attachment; filename=regulatory.xlsx");
//
//        return ResponseEntity
//                .ok()
//                .headers(headers)
//                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
//                .body(new InputStreamResource(byteArrayInputStream));
//    }

}
