package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.DataChange;
import com.services.hiportservices.model.compliance.ComplianceDataChange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplianceDataChangeRepository extends JpaRepository<ComplianceDataChange, Long> {

    List<ComplianceDataChange> findByApprovalStatus(ApprovalStatus ApprovalStatus);
    List<ComplianceDataChange> findByEntityClassName(String entityClassName);

    List<ComplianceDataChange> findAllByApprovalStatus (ApprovalStatus approvalStatus);

    @Query(value="SELECT * FROM comp_data_change WHERE approval_status = 'Pending'", nativeQuery = true)
    List<ComplianceDataChange> searchAllByApprovalStatusPending();

    @Query(value="SELECT * FROM comp_data_change WHERE id = :idData and approval_status = 'Pending'", nativeQuery = true)
    ComplianceDataChange searchDataForApproveOrReject(@Param("idData") Long id);


}
