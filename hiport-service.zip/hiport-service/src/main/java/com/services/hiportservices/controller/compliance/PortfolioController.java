package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.dto.request.compliance.PortfolioTypeRequestDTO;
import com.services.hiportservices.service.compliance.PortfolioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/portfolio")
public class PortfolioController {
    @Autowired
    PortfolioService portfolioService;

    @PostMapping
    public ResponseEntity<ResponseDto> save(@RequestBody PortfolioRequestDTO portfolioRequestDTO)  {
        return portfolioService.insertPortfolioType(portfolioRequestDTO);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> searchPortfolio(@RequestParam String findByCode)  {
        return portfolioService.searchPortfolio(findByCode);
    }

    @GetMapping("/all")
    public ResponseEntity<ResponseDto> findAllPortfolio()  {
        return portfolioService.findAllPortfolio();
    }


    @GetMapping("/{code}")
    public ResponseEntity<ResponseDto> getByCode(@PathVariable String code)  {
        return portfolioService.getByCode(code);
    }

    @PutMapping("/delete/{code}")
    public ResponseEntity<ResponseDto> deleteById(@PathVariable String code)  {
        return portfolioService.deleteByCode(code);
    }

    @PutMapping("/upload/{param}")
    public ResponseEntity<ResponseDto> uploadFileReksadana(@PathVariable String param, @RequestBody List<Map<String, String>> portfolioList) {
        return portfolioService.insertPortfolioUpload(param, portfolioList);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return portfolioService.allPendingDataPortfolio();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return portfolioService.approveDataPortfolio(codeList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return portfolioService.rejectDataPortfolio(codeList);
    }
}
