package com.services.hiportservices.controller.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd13;
import com.services.hiportservices.service.emonitoring.OrchidXd13Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd13")
public class OrchidXD13Controller {
    @Autowired
    OrchidXd13Service orchidXd13Service;
    Logger logger = LoggerFactory.getLogger(OrchidXD13Controller.class);


    @GetMapping("/getDataXD13")
    public List<OrchidXd13> getDataXD13(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd13Service.getDataXD13(date, pf);
    }
}
