
package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_afiliasi")
public class Afiliasi extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name="reksadana_code", nullable=false)
    private Reksadana reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "afiliasi")
    private String afiliasi;

    @Column(name = "kode_efek", nullable=false)
    private String kodeEfek;
}
