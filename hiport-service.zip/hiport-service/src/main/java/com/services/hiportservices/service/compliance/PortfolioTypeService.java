package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.controller.MasterController;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioTypeRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.ComplianceDataChangeRepository;
import com.services.hiportservices.repository.compliance.PortfolioTypeRepository;
import com.services.hiportservices.service.DataChangeService;
import com.services.hiportservices.utils.UserIdUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class PortfolioTypeService {
    Logger logger = LoggerFactory.getLogger(PortfolioTypeService.class);

    @Autowired
    PortfolioTypeRepository portfolioTypeRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;


    public ResponseEntity<ResponseDto> insertPortfolioType(PortfolioTypeRequestDTO pfTypeDTO) {
        String message = "Success insert new portfolio type";
        ResponseDto responseDto = new ResponseDto();
        PortfolioType portfolioType = portfolioTypeRepository.findByPortfolioType(pfTypeDTO.getPortfolioType());
        try {
            if(portfolioType == null){
                portfolioType = new PortfolioType();
                portfolioType.setApprovalStatus(ApprovalStatus.Pending);
                portfolioType.setInputDate(new Date());
                portfolioType.setInputerId(UserIdUtil.getUser());
                portfolioType.setDelete(false);
                portfolioType.setPortfolioType(pfTypeDTO.getPortfolioType());
                portfolioType.setName(pfTypeDTO.getName());
                portfolioType.setDescription(pfTypeDTO.getDescription());
                logger.info("Insert Portofoliotype");
                portfolioTypeRepository.save(portfolioType);

            } else {
                PortfolioType portfolioTypeAfter = new PortfolioType();
                portfolioTypeAfter.setInputDate(new Date());
                portfolioTypeAfter.setInputerId(UserIdUtil.getUser());
                portfolioTypeAfter.setDelete(false);
                portfolioTypeAfter.setName(pfTypeDTO.getName());
                portfolioTypeAfter.setDescription(pfTypeDTO.getDescription());

                ObjectMapper Obj = new ObjectMapper();
                String jsonbefore = Obj.writeValueAsString(portfolioType);
                ObjectMapper ObjAfter = new ObjectMapper();
                String jsonAfter = ObjAfter.writeValueAsString(portfolioTypeAfter);

                ComplianceDataChange dataChange = new ComplianceDataChange();
                dataChange.setApprovalStatus(ApprovalStatus.Pending);
                dataChange.setInputerId(UserIdUtil.getUser());
                dataChange.setInputDate(new Date());
                dataChange.setAction(ChangeAction.Edit);
                dataChange.setEntityId(String.valueOf(portfolioType.getPortfolioType()));
                dataChange.setTableName("comp_portfolio_type");
                dataChange.setEntityClassName(PortfolioType.class.getName());
                dataChange.setDataBefore(jsonbefore);
                dataChange.setDataChange(jsonAfter);
                complianceDataChangeRepository.save(dataChange);

                message = "Success update portfolio type";
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(message);
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getAllData() {

        ResponseDto responseDto =new com.services.hiportservices.dto.ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioTypeRepository.findAll());

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getAllByDelete() {

        ResponseDto responseDto =new com.services.hiportservices.dto.ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioTypeRepository.findAllByDeleteAndApprovalStatus(false, ApprovalStatus.Approved));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> deleteById(int id) {
        ResponseDto responseDto = new ResponseDto();
        PortfolioType pfType = portfolioTypeRepository.findByPortfolioType(id);
        try {
            if(pfType != null){
                PortfolioType portfolioTypeAfter = new PortfolioType();
                portfolioTypeAfter.setDelete(true);

                ObjectMapper Obj = new ObjectMapper();
                String jsonbefore = Obj.writeValueAsString(pfType);
                ObjectMapper ObjAfter = new ObjectMapper();
                String jsonAfter = ObjAfter.writeValueAsString(portfolioTypeAfter);

                ComplianceDataChange dataChange = new ComplianceDataChange();
                dataChange.setApprovalStatus(ApprovalStatus.Pending);
                dataChange.setInputerId(UserIdUtil.getUser());
                dataChange.setInputDate(new Date());
                dataChange.setAction(ChangeAction.Delete);
                dataChange.setEntityId(String.valueOf(id));
                dataChange.setTableName("comp_portfolio_type");
                dataChange.setEntityClassName(PortfolioType.class.getName());
                dataChange.setDataBefore(jsonbefore);
                dataChange.setDataChange(jsonAfter);
                complianceDataChangeRepository.save(dataChange);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Delete Success where id " + id + "!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getByPortfolioType(int pfType) {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioTypeRepository.findByPortfolioType(pfType));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);

    }

    public ResponseEntity<ResponseDto> allPendingDataPortfolioType() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioTypeRepository.searchPendingData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataPortfolioType(Map<String, List<String>> codeList) {
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            portfolioTypeRepository.approveOrRejectPortfolioType("Approved", new Date(), approverId, Integer.valueOf(code));
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataPortfolioType(Map<String, List<String>> codeList) {
        ResponseDto responseDto = new ResponseDto();
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        try {
            for (String code : codes){
                PortfolioType portfolioType = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(code));
                portfolioTypeRepository.delete(portfolioType);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have rejected!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
