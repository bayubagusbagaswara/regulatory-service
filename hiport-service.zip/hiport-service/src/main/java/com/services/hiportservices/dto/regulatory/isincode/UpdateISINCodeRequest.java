package com.services.hiportservices.dto.regulatory.isincode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateISINCodeRequest extends InputIdentifierRequest {

    private Long id;

    private String externalCode;

    private String currency;

    private String isinLKPBU;

    private String isinLBABK;

}
