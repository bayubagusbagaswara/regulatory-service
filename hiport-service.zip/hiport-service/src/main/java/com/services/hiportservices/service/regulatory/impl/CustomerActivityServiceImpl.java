package com.services.hiportservices.service.regulatory.impl;

import com.opencsv.exceptions.CsvException;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.exception.CsvHandleException;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.exception.GeneralHandleException;
import com.services.hiportservices.model.regulatory.CustomerActivity;
import com.services.hiportservices.repository.regulatory.CustomerActivityRepository;
import com.services.hiportservices.service.regulatory.CustomerActivityService;
import com.services.hiportservices.utils.regulatory.CsvDataMapper;
import com.services.hiportservices.utils.regulatory.CsvReaderUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class CustomerActivityServiceImpl implements CustomerActivityService {

    @Value("${file.path.customer-activity}")
    private String filePath;

    private static final String BASE_FILE_NAME = "CustomerActivity_";

    private final CustomerActivityRepository customerActivityRepository;
    private final DateUtil dateUtil;

    @Override
    public String readAndInsertToDB() {
        log.info("Start read and insert Customer Activity data to the database");
        String filePathNew = "";
        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());
            String monthNameMinus1 = contextDate.getMonthNameMinus1();
            String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
            Integer yearMinus1 = contextDate.getYearMinus1();

            String fileName = BASE_FILE_NAME + yearMinus1 + monthNameMinus1Value + ".csv";
            filePathNew = filePath + fileName;

            File file = new File(filePathNew);
            if (!file.exists()) {
                throw new DataNotFoundHandleException("Customer Activity file not found with path: " + filePathNew);
            }

            customerActivityRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

            List<String[]> rows = CsvReaderUtil.readCsvFileAndSkipFirstLine(filePathNew);
            List<CustomerActivity> customerActivityList = CsvDataMapper.mapCsvCustomerActivity(rows);

            customerActivityRepository.saveAll(customerActivityList);

            return "Customer Activity data processed and saved successfully";
        } catch (DataNotFoundHandleException e) {
            log.error("Customer Activity file not found: {}", e.getMessage(), e);
            throw new DataNotFoundHandleException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error("Customer Activity failed to process CSV data from file: {}", filePathNew, e);
            throw new CsvHandleException("Customer Activity failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", filePathNew, e);
            throw new GeneralHandleException("Customer Activity unexpected error: " + e.getMessage());
        }
    }

}
