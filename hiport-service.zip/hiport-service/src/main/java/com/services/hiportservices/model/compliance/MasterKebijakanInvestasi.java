package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_master_kinv")
public class MasterKebijakanInvestasi extends Approvable {
    @Id
    @Column(name = "kinv_code", nullable=false)
    private String kinvCode;

    @Column(name = "kinv_name")
    private String kebijakanName;

    @Column(name = "portfolio_types", nullable=false)
    private String types;

    @Column(name = "isDelete")
    private boolean delete;
}
