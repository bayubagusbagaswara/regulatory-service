package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.ComplianceDataChange;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.compliance.PortfolioKINVGrouping;
import com.services.hiportservices.model.compliance.PortfolioType;
import com.services.hiportservices.repository.compliance.ComplianceDataChangeRepository;
import com.services.hiportservices.repository.compliance.PortfolioRepository;
import com.services.hiportservices.repository.compliance.PortfolioTypeRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class PortfolioService {

    @Autowired
    PortfolioRepository portfolioRepository;

    @Autowired
    PortfolioTypeRepository portfolioTypeRepository;

    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;

    public ResponseEntity<ResponseDto> insertPortfolioType(PortfolioRequestDTO portfolioRequestDTO) {
        String message = "Success insert new portfolio";
        PortfolioType portfolioType = portfolioTypeRepository.findByPortfolioType(portfolioRequestDTO.getPortfolioType());
        Portfolio portfolio = portfolioRepository.findByCode(portfolioRequestDTO.getCode());

        try {
            if (portfolio == null) {
                portfolio = new Portfolio();
                portfolio.setApprovalStatus(ApprovalStatus.Pending);
                portfolio.setInputDate(new Date());
                portfolio.setInputerId(UserIdUtil.getUser());
                portfolio.setDelete(false);
                portfolio.setCode(portfolioRequestDTO.getCode());
                portfolio.setName(portfolioRequestDTO.getName());
                portfolio.setIssuer(portfolioRequestDTO.getIssuer());
                portfolio.setExternalCode(portfolioRequestDTO.getExternalCode());
                portfolio.setPortfolioType(portfolioType);
                portfolio.setDescription(portfolioRequestDTO.getDescription());
                portfolio.setSyariah(portfolioRequestDTO.isSyariah());
                portfolio.setConventional(portfolioRequestDTO.isConventional());
                portfolioRepository.save(portfolio);

            } else {

                Portfolio portfolioAfter = new Portfolio();
                portfolioAfter.setApprovalStatus(ApprovalStatus.Pending);
                portfolioAfter.setInputDate(new Date());
                portfolioAfter.setInputerId(UserIdUtil.getUser());
                portfolioAfter.setDelete(false);
                portfolioAfter.setName(portfolioRequestDTO.getName());
                portfolioAfter.setIssuer(portfolioRequestDTO.getIssuer());
                portfolioAfter.setExternalCode(portfolioRequestDTO.getExternalCode());
                portfolioAfter.setPortfolioType(portfolioType);
                portfolioAfter.setDescription(portfolioRequestDTO.getDescription());
                portfolioAfter.setSyariah(portfolioRequestDTO.isSyariah());
                portfolioAfter.setConventional(portfolioRequestDTO.isConventional());
//                portfolioRepository.save(portfolio);

                ObjectMapper Obj = new ObjectMapper();
                String jsonbefore = Obj.writeValueAsString(portfolio);
                ObjectMapper ObjAfter = new ObjectMapper();
                String jsonAfter = ObjAfter.writeValueAsString(portfolioAfter);


                ComplianceDataChange dataChange = new ComplianceDataChange();
                dataChange.setApprovalStatus(ApprovalStatus.Pending);
                dataChange.setInputerId(UserIdUtil.getUser());
                dataChange.setInputDate(new Date());
                dataChange.setAction(ChangeAction.Edit);
                dataChange.setEntityId(portfolio.getCode());
                dataChange.setTableName("comp_portfolio");
                dataChange.setEntityClassName(Portfolio.class.getName());
                dataChange.setDataBefore(jsonbefore);
                dataChange.setDataChange(jsonAfter);
                complianceDataChangeRepository.save(dataChange);

                message = "Success update portfolio";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ResponseDto responseDto = new com.services.hiportservices.dto.ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(message);

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }


    public ResponseEntity<ResponseDto> getByCode(String code) {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioRepository.findByCode(code));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> deleteByCode(String code) {
        ResponseDto responseDto = new ResponseDto();
        try {
            Portfolio portfolio = portfolioRepository.findByCode(code);

            Portfolio portfolioAfter = new Portfolio();
            portfolioAfter.setInputDate(new Date());
            portfolioAfter.setInputerId(UserIdUtil.getUser());
            portfolioAfter.setDelete(true);

            ObjectMapper Obj = new ObjectMapper();
            String jsonbefore = Obj.writeValueAsString(portfolio);
            ObjectMapper ObjAfter = new ObjectMapper();
            String jsonAfter = ObjAfter.writeValueAsString(portfolioAfter);

            ComplianceDataChange dataChange = new ComplianceDataChange();
            dataChange.setApprovalStatus(ApprovalStatus.Pending);
            dataChange.setInputerId(UserIdUtil.getUser());
            dataChange.setInputDate(new Date());
            dataChange.setAction(ChangeAction.Delete);
            dataChange.setEntityId(portfolio.getCode());
            dataChange.setTableName("comp_portfolio");
            dataChange.setEntityClassName(Portfolio.class.getName());
            dataChange.setDataBefore(jsonbefore);
            dataChange.setDataChange(jsonAfter);
            complianceDataChangeRepository.save(dataChange);

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Delete success where code " + code + "!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> searchPortfolio(String findByCode) {
        List<Portfolio> portfolioList = portfolioRepository.searchByCodeLike(ApprovalStatus.Approved, findByCode);

        if (portfolioList.size() == 0) {
            portfolioList = portfolioRepository.searchByExternalCodeLike(ApprovalStatus.Approved, findByCode);
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioList);

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findAllPortfolio() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioRepository.findAllByDeleteAndApprovalStatus(false, ApprovalStatus.Approved));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<ResponseDto> insertPortfolioUpload(String param, List<Map<String, String>> portfolioList) {
        String message = "Input data success!";
        ResponseDto responseDto = new ResponseDto();
        List<Portfolio> newPortfolioList = new ArrayList<>();
        List<ComplianceDataChange> newComplianceDataChange = new ArrayList<>();
        try {
            if (param.equalsIgnoreCase("new")) {
                int row = 0;
                for (Map<String, String> portfolio : portfolioList) {
                    row += 1;
                    String securityCode = portfolio.get("securityCode").trim();
                    String externalCode = portfolio.get("externalCode").trim();
                    String securityName = portfolio.get("securityName");
                    String portfolioTypeString = portfolio.get("portfolioType").trim();
                    String issuer = portfolio.get("issuer");
                    String convSyr = portfolio.get("conven/syariah");
                    String desc = portfolio.get("desc");

                    if (securityCode == "" || securityCode == null || securityCode.isEmpty() || externalCode == "" || externalCode == null || externalCode.isEmpty() ||
                            securityName == "" || securityName == null || securityName.isEmpty() ||
                            convSyr == "" || convSyr == null || convSyr.isEmpty() || portfolioTypeString == "" || portfolioTypeString == null || portfolioTypeString.isEmpty() ||
                            issuer == "" || issuer == null || issuer.isEmpty()){
                        throw new Exception("Required properties are missing in Row " + row + "!");
                    }

                    boolean conventional = false;
                    boolean syariah = true;
                    if (convSyr.equalsIgnoreCase("conventional") || convSyr.equalsIgnoreCase("conven")) {
                        conventional = true;
                        syariah = false;
                    } else if (convSyr.equalsIgnoreCase("both")) {
                        conventional = true;
                        syariah = true;
                    }

                    PortfolioType portfolioType = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(portfolioTypeString));
                    if (portfolioType == null) {
                        throw new Exception("Wrong Portfolio Type!");
                    }

                    Portfolio pf = portfolioRepository.findByCode(securityCode);
                    if (pf != null && pf.isDelete() == false) {
                        throw new Exception("Portfolio " + securityCode + " has been regestered!");
                    } else {
                        pf = new Portfolio();
                        pf.setCode(securityCode);
                        pf.setApprovalStatus(ApprovalStatus.Pending);
                        pf.setInputDate(new Date());
                        pf.setInputerId(UserIdUtil.getUser());
                        pf.setDelete(false);
                        pf.setName(securityName);
                        pf.setExternalCode(externalCode);
                        pf.setIssuer(issuer);
                        pf.setDescription(desc);
                        pf.setConventional(conventional);
                        pf.setSyariah(syariah);
                        pf.setPortfolioType(portfolioType);
                        newPortfolioList.add(pf);
                    }
                }
                portfolioRepository.saveAll(newPortfolioList);
            } else {
                int row = 0;
                for (Map<String, String> portfolio : portfolioList) {
                    row += 0;
                    String securityCode = portfolio.get("securityCode").trim();
                    Portfolio portfolioAfter = new Portfolio();
                    Portfolio portfolioBefore = new Portfolio();
                    if (securityCode == "" || securityCode == null || securityCode.isEmpty()) {
                        throw new Exception("Required properties are missing in " + row + "!");
                    } else {
                        portfolioBefore = portfolioRepository.findByCode(securityCode);
                        if (portfolioBefore == null) {
                            throw new Exception("Portfolio " + securityCode + " is not registered!");
                        }
                        portfolioAfter.setInputDate(new Date());
                        portfolioAfter.setInputerId(UserIdUtil.getUser());
                        portfolioAfter.setDelete(false);
                    }

                    String externalCode = portfolio.get("externalCode").trim();
                    if (externalCode != null || !externalCode.isEmpty() || externalCode == "") {
                        portfolioAfter.setExternalCode(externalCode);
                    } else {
                        portfolioAfter.setExternalCode(portfolioBefore.getExternalCode());
                    }

                    String securityName = portfolio.get("securityName");
                    if (securityName != null || !securityName.isEmpty() || securityName == "") {
                        portfolioAfter.setName(securityName);
                    }else {
                        portfolioAfter.setName(portfolioBefore.getName());
                    }

                    String portfolioTypeString = portfolio.get("portfolioType").trim();

                    if (portfolioTypeString != null || !portfolioTypeString.isEmpty() || portfolioTypeString == "") {
                        PortfolioType portfolioType = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(portfolioTypeString));
                        if (portfolioType == null ) {
                            throw new Exception("Wrong Portfolio Type in Row " + row + "!");
                        } else {
                            portfolioAfter.setPortfolioType(portfolioType);
                        }
                    }else{
                        portfolioAfter.setPortfolioType(portfolioBefore.getPortfolioType());
                    }

                    String issuer = portfolio.get("issuer");
                    if (issuer != null || !issuer.isEmpty() || issuer == "") {
                        portfolioAfter.setIssuer(issuer);
                    }else{
                        portfolioAfter.setIssuer(portfolioBefore.getIssuer());
                    }

                    String convSyr = portfolio.get("conven/syariah");
                    if (convSyr != null || !convSyr.isEmpty() || convSyr=="") {
                        boolean conventional = false;
                        boolean syariah = true;
                        if (convSyr.equalsIgnoreCase("conventional")) {
                            conventional = true;
                            syariah = false;
                        } else if (convSyr.equalsIgnoreCase("both")) {
                            conventional = true;
                            syariah = true;
                        }
                        portfolioAfter.setConventional(conventional);
                        portfolioAfter.setSyariah(syariah);
                    }else{
                        portfolioAfter.setConventional(portfolioBefore.isConventional());
                        portfolioAfter.setSyariah(portfolioBefore.isSyariah());
                    }

                    String desc = portfolio.get("desc");
                    if (desc == null || desc.isEmpty() || desc == "") {
                        portfolioAfter.setDescription(portfolioBefore.getDescription());

                    }else{
                        portfolioAfter.setDescription(desc);
                    }

                    ObjectMapper Obj = new ObjectMapper();
                    String jsonbefore = Obj.writeValueAsString(portfolioBefore);
                    ObjectMapper ObjAfter = new ObjectMapper();
                    String jsonAfter = ObjAfter.writeValueAsString(portfolioAfter);

                    ComplianceDataChange dataChange = new ComplianceDataChange();
                    dataChange.setApprovalStatus(ApprovalStatus.Pending);
                    dataChange.setInputerId(UserIdUtil.getUser());
                    dataChange.setInputDate(new Date());
                    dataChange.setAction(ChangeAction.Edit);
                    dataChange.setEntityId(portfolioBefore.getCode());
                    dataChange.setTableName("comp_portfolio");
                    dataChange.setEntityClassName(Portfolio.class.getName());
                    dataChange.setDataBefore(jsonbefore);
                    dataChange.setDataChange(jsonAfter);

                    newComplianceDataChange.add(dataChange);
                }
                complianceDataChangeRepository.saveAll(newComplianceDataChange);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataPortfolio() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(portfolioRepository.searchPendingPortfolioData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataPortfolio(Map<String, List<String>> codeList) {
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            portfolioRepository.approveOrRejectPortfolio("Approved", new Date(), approverId, code);
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataPortfolio(Map<String, List<String>> codeList) {
        ResponseDto responseDto = new ResponseDto();
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        try {
            for (String code : codes){
                Portfolio portfolio = portfolioRepository.findByCode(code);
                portfolioRepository.delete(portfolio);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have rejected!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
