package com.services.hiportservices.service;

import com.services.hiportservices.controller.MasterController;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.response.DataChangeResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.Approvable;
import com.services.hiportservices.model.DataChange;
import com.services.hiportservices.model.compliance.MasterKebijakanInvestasi;
import com.services.hiportservices.repository.DataChangeRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.apache.commons.lang.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import javax.persistence.EntityNotFoundException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.*;
@Service
public class DataChangeService {
    @Autowired
    DataChangeRepository dataChangeRepository;

    @Autowired
    ApplicationContext applicationContext;
    Logger logger = LoggerFactory.getLogger(DataChangeService.class);


    public ResponseEntity<ResponseDto> getDataChangeAll(){
        return new ResponseEntity<>(
                new ResponseDto().builder()
                        .code(HttpStatus.OK.toString())
                        .message("Succses approve data")
                        .payload(findAllData())
                        .build(),HttpStatus.OK
        );
    }

    private List<DataChangeResponseDto> findAllData(){
        List<DataChangeResponseDto> DataChangeListResp =  new ArrayList<>();

        List<DataChange> dataChangeList = dataChangeRepository.findAll();
        dataChangeList.forEach((e)->{
            String data = null;
            try {
                Class<?> entityClass = Class.forName(e.getEntityClassName());
                data = entityClass.getSimpleName();
            } catch (ClassNotFoundException e1) {
                e1.printStackTrace();
            }

            SimpleDateFormat DateFormat = new SimpleDateFormat("MM/dd/yyyy");
            String inputDate = DateFormat.format(e.getInputDate());
            Object dataBefore = e.getAction().equals(ChangeAction.Add)
                    ? null : getDataBefore(e.getEntityClassName(),e.getEntityId());

            DataChangeResponseDto dataChangeResponseDto = new DataChangeResponseDto();
            dataChangeResponseDto.setIdDataChange(e.getId());
            dataChangeResponseDto.setAction(e.getAction());
            dataChangeResponseDto.setEntityId(e.getEntityId());
            dataChangeResponseDto.setInputDate(inputDate);
            dataChangeResponseDto.setInputerId(e.getInputerId());
            dataChangeResponseDto.setEntityClassName(data);
            dataChangeResponseDto.setDataBefore(dataBefore);
            dataChangeResponseDto.setDataAfter(SerializationUtils.deserialize(e.getChangedObject()));

            DataChangeListResp.add(dataChangeResponseDto);
        });


     return DataChangeListResp;

    }

    private Object getDataBefore(String entityClassName, String entityId) {
        try {
            // get kelas berdasarkan entityClassName
            Class<?> entityClass = Class.forName(entityClassName);
            String entityName = entityClass.getSimpleName();
            String firstLetterLowercase = Character.toLowerCase(entityName.charAt(0)) + entityName.substring(1); // Ubah huruf pertama menjadi huruf kecil
            String repositoryName = firstLetterLowercase + "Repository"; // Buat nama repository


            // mencari repository berdasarkan nama
            JpaRepository<Object, String> repository = (JpaRepository<Object, String>) applicationContext.getBean(repositoryName);
            // menemukan object berdasarkan ID
            Object dataBeforeEntity = repository.findById(entityId)
                    .orElseThrow(() -> new EntityNotFoundException("Entity not found"));

            return dataBeforeEntity;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }


    public ResponseEntity<ResponseDto> doReject(Long id){
        DataChange dataChange = dataChangeRepository.findById(id).orElseThrow(()-> new RuntimeException("No data!"));
        dataChange.setApproveDate(new Date());
        dataChange.setApproverId(UserIdUtil.getUser());
        dataChange.setApprovalStatus(ApprovalStatus.Rejected);
        dataChangeRepository.save(dataChange);

        return new ResponseEntity<>(
                new ResponseDto().builder()
                .code(HttpStatus.CREATED.toString())
                .message("Succses approve data")
                .payload(SerializationUtils.deserialize(dataChange.getChangedObject()))
                .build(),HttpStatus.CREATED
        );
    }

    public ResponseEntity<ResponseDto> doApprove(Long id){
        DataChange dataChange = dataChangeRepository.findById(id).orElseThrow(()-> new RuntimeException("No data!"));
        dataChange.setApproveDate(new Date());
        dataChange.setApproverId(UserIdUtil.getUser());
        dataChange.setApprovalStatus(ApprovalStatus.Approved);
        dataChangeRepository.save(dataChange);

        return new ResponseEntity<>(
                new ResponseDto().builder()
                        .code(HttpStatus.CREATED.toString())
                        .message("Succses approve data")
                        .payload(SerializationUtils.deserialize(dataChange.getChangedObject()))
                        .build(),HttpStatus.CREATED
        );
    }

    public void createAddRequest(Approvable newEntity, String entityIdType) {

        DataChange add = new DataChange();
        add.setAction(ChangeAction.Add);
        add.setEntityClassName(newEntity.getClass().getName());
        add.setEntityIdType("");
        add.setEntityId(entityIdType);
        add.setChangedObject(SerializationUtils.serialize(newEntity));
        add.setInputerId(UserIdUtil.getUser());
        add.setInputDate(new Date());
        add.setApprovalStatus(ApprovalStatus.Pending);

        dataChangeRepository.save(add);
    }

    public void createEditRequest(Approvable changedEntity, String entityIdType, String entityId, String inputerId) {

        DataChange edit = new DataChange();
        edit.setAction(ChangeAction.Edit);
        edit.setEntityClassName(changedEntity.getClass().getName());
        edit.setEntityIdType(entityIdType);
        edit.setEntityId(entityId);
        edit.setChangedObject(SerializationUtils.serialize(changedEntity));
        edit.setInputerId(inputerId);
        edit.setInputDate(new Date());
        edit.setApprovalStatus(ApprovalStatus.Pending);
        edit.setApproverId(UserIdUtil.getUser());
        logger.info("Insert to DataChange");
        dataChangeRepository.save(edit);
    }
    public void createDeleteRequest(Approvable changedEntity, String entityIdType, String entityId, String inputerId){
        DataChange edit = new DataChange();
        edit.setAction(ChangeAction.Delete);
        edit.setApprovalStatus(ApprovalStatus.Pending);
        edit.setEntityClassName(changedEntity.getClass().getName());
        edit.setEntityIdType(entityIdType);
        edit.setEntityId(entityId);
        edit.setChangedObject(SerializationUtils.serialize(changedEntity));
        edit.setInputerId(inputerId);
        edit.setInputDate(new Date());
        edit.setApproverId(UserIdUtil.getUser());
        logger.info("Insert to DataChange action delete");
        System.out.println(edit.getApprovalStatus());
        dataChangeRepository.save(edit);
    }



}
