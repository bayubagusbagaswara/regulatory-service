package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.dto.request.compliance.ReksadanaTypeRequestDTO;
import com.services.hiportservices.model.compliance.ReksadanaType;
import com.services.hiportservices.service.compliance.PortfolioService;
import com.services.hiportservices.service.compliance.ReksadanaTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/rdType")
public class ReksadanaTypeController {
    @Autowired
    ReksadanaTypeService reksadanaTypeService;

    @PostMapping
    public ResponseEntity<ResponseDto> save(@RequestBody ReksadanaTypeRequestDTO reksadanaTypeRequestDTO)  {
        return reksadanaTypeService.insertReksadanaType(reksadanaTypeRequestDTO);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> findAllData()  {
        return reksadanaTypeService.getAllReksadanaType();
    }

    @GetMapping("/{rdType}")
    public ResponseEntity<ResponseDto> getByCode(@PathVariable String rdType)  {
        return reksadanaTypeService.getByReksadanaType(rdType);
    }

    @PutMapping("/delete/{code}")
    public ResponseEntity<ResponseDto> deleteById(@PathVariable String code)  {
        return reksadanaTypeService.deleteByReksadanaCode(code);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return reksadanaTypeService.allPendingDataReksadanaType();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithCode(@RequestBody Map<String, List<String>> idList) {
        System.out.println(idList);
        return reksadanaTypeService.approveDataReksadanaType(idList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        System.out.println(codeList);
        return reksadanaTypeService.rejectDataReksadanaType(codeList);
    }
}
