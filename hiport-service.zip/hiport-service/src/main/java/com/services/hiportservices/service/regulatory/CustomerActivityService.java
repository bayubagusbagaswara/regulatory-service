package com.services.hiportservices.service.regulatory;

public interface CustomerActivityService {

    String readAndInsertToDB();

}
