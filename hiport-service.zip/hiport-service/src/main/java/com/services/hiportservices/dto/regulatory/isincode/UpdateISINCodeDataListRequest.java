package com.services.hiportservices.dto.regulatory.isincode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * tarus anotasi validasi dan JsonProperty disini
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateISINCodeDataListRequest {

    @JsonProperty(value = "External Code")
    private String externalCode;

    @JsonProperty(value = "Currency")
    private String currency;

    @JsonProperty(value = "ISIN LKPBU")
    private String isinLKPBU;

    @JsonProperty(value = "ISIN LBABK")
    private String isinLBABK;

}
