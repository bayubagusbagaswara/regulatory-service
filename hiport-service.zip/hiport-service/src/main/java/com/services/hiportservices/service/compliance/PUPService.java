package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class PUPService {

    @Autowired
    ReksadanaRepository reksadanaRepository;
    @Autowired
    AfiliasiRepository afiliasiRepository;
    @Autowired
    PortfolioRepository portfolioRepository;
    @Autowired
    PUPRepository pupRepository;
    @Autowired
    EntityManager entityManager;
    @Autowired
    PUPRecordRepository pupRecordRepository;

    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    @Transactional
    public ResponseEntity<ResponseDto> insertDataPUP(String date, List<Map<String, String>> pupList) {
        String message = "Input data success!";

        ResponseDto responseDto = new ResponseDto();

        try {
            List<PUP> pupData = new ArrayList<>();
            Date dateOfData = format.parse(date);
            for (Map<String, String> pupRequestDTO : pupList) {
                String reksadanaCode = pupRequestDTO.get("ProductCode").trim();
                String reksadanaName = pupRequestDTO.get("ProductName");
                String pupTotal = pupRequestDTO.get("JumlahPUP");

                PUP pup = pupRepository.searchByReksadanaCodeAndDate(reksadanaCode, dateOfData);
                if (pup == null) {
                    pup = new PUP();
                }
                pup.setApprovalStatus(ApprovalStatus.Pending);
                pup.setApproveDate(null);
                pup.setApproverId(null);
                pup.setInputDate(new Date());
                pup.setInputerId(UserIdUtil.getUser());
                pup.setDate(dateOfData);
                pup.setReksadanaCode(reksadanaCode);
                pup.setReksadanaName(reksadanaName);
                pup.setPupTotal(Integer.valueOf(pupTotal));

                if (reksadanaCode == null) {
                    throw new Exception("Reksadana Code Empty");
                }

                pupData.add(pup);
            }

            pupRepository.saveAll(pupData);

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);

        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findDataAt(String date) {
        Date dateOfData = null;
        try {
            dateOfData = format.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(pupRepository.searchByDataDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataPUP() {
        List<Map<String, Object>> listPendingDataFairPrice = new ArrayList<>();
        ResponseDto responseDto =new ResponseDto();
        try {
            Query query = entityManager.createNativeQuery(
                    "select data_date, count(*), inputer_id from comp_pup " +
                            "where approval_status = 'Pending' " +
                            "group by data_date, inputer_id");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("date", data[0]);
                eachColumn.put("totalData", data[1]);
                eachColumn.put("inputerId", data[2]);

                listPendingDataFairPrice.add(eachColumn);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(listPendingDataFairPrice);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataPUP(String date) {
        ResponseDto responseDto =new ResponseDto();
        String approverId = UserIdUtil.getUser();
        try {
            List<PUPRecord> pupRecordList = new ArrayList<>();
            pupRepository.approveOrRejectPUP("Approved", new Date(), approverId, date);

            Date dateOfData = format.parse(date);
            List<PUP> pupList = pupRepository.searchByDataDate(dateOfData);

            for (PUP pup : pupList){
                String reksdanaCode = pup.getReksadanaCode();
                PUPRecord pupRecord = pupRecordRepository.searchByReksadanaCode(reksdanaCode);

                if (pupRecord == null){
                    pupRecord = new PUPRecord();
                    pupRecord.setPreviousDaysTotal(0);
                    pupRecord.setPupTotal(pup.getPupTotal());
                    pupRecord.setDaysTotal(1);
                    pupRecord.setChangesDate(dateOfData);
                    pupRecord.setBreachStarted(dateOfData);
                } else {
//                    System.out.println("PUP -> Date now: " + dateOfData + " and changeDate: " + pupRecord.getChangesDate());
                    if(!dateOfData.equals(pupRecord.getChangesDate()) && dateOfData.after(pupRecord.getChangesDate()) && !dateOfData.before(pupRecord.getChangesDate())){
                        pupRecord.setPreviousDaysTotal(pupRecord.getDaysTotal());
                        pupRecord.setPupTotal(pup.getPupTotal());
                        pupRecord.setDaysTotal(pupRecord.getDaysTotal() + 1);
                        pupRecord.setChangesDate(dateOfData);
                    }
                }
                pupRecord.setReksadanaCode(pup.getReksadanaCode());
                pupRecord.setReksadanaName(pup.getReksadanaName());

                pupRecordList.add(pupRecord);
            }

            pupRecordRepository.saveAll(pupRecordList);

            //After Save PUP record -> Check data to update data that not breach (RESTART TOTAL DAYS PUP)
            List<PUPRecord> pupRecords = pupRecordRepository.searchAllPupRecordNotInDate(date);
            for(PUPRecord record : pupRecords){
                if (!dateOfData.equals(record.getChangesDate()) && !dateOfData.before(record.getChangesDate())){
                    record.setDaysTotal(0);
                    record.setPupTotal(0);
                    record.setPreviousDaysTotal(0);
                    record.setChangesDate(dateOfData);
                    record.setBreachEnded(dateOfData);
                    pupRecordRepository.save(record);

                }
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have approved!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataPUP(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            pupRepository.approveOrRejectPUP("Rejected", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> viewPendingData(String date) {
        Date dateOfData = null;
        try {
            dateOfData = format.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(pupRepository.searchPendingData(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
