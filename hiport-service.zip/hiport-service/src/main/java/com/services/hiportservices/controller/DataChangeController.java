package com.services.hiportservices.controller;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.DataChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/dataChange")
public class DataChangeController {
    @Autowired
    DataChangeService dataChangeService;

    @GetMapping
    public ResponseEntity<ResponseDto> getall(){
        return dataChangeService.getDataChangeAll();
    }

    @PutMapping("/approve/{id}")
    public ResponseEntity<ResponseDto> doApprove(@PathVariable Long id){
        return dataChangeService.doApprove(id);
    }

    @PutMapping("/reject/{id}")
    public ResponseEntity<ResponseDto>  doReject(@PathVariable Long id){
        return dataChangeService.doReject(id);
    }



}
