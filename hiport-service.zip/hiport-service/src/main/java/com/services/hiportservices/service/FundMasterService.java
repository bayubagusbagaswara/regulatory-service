package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.response.ResponseFundMasterDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class FundMasterService {
    public ResponseEntity<ResponseDto> updateFunMaster() throws ClassNotFoundException, SQLException {
        List<ResponseFundMasterDto> responseFundMasterDtoList = new ArrayList();

        Class.forName("com.dstglobalsolutions.dro.jdbc.openaccess.OpenAccessDriver");
        Connection con = DriverManager.getConnection("jdbc:DRO://10.197.31.137:29996;ServerDataSource=HIPORTDSN;USER=SSNC;PASSWORD=HIPORT04");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT A.PFCODE, B.USERDEFINEDFIELD28,B.USERDEFINEDFIELD29, B.USERDEFINEDFIELD30,  C.LONGNAME FROM PORTFOLIOGROUP A, PORTFOLIOUSERDEFINED B, PORTFOLIO C WHERE A.[GROUPCODE] = 'NFS' AND A.PFCODE = B.CODE AND A.PFCODE = C.CODE");

        while (rs.next()){
            ResponseFundMasterDto responseFundMasterDto = ResponseFundMasterDto.builder()
                    .pfCode(rs.getString("pfcode"))
                    .userDefinedField28(rs.getString("userDefinedField28"))
                    .userDefinedField29(rs.getString("userDefinedField29"))
                    .userDefinedField30(rs.getString("userDefinedField30"))
                    .longName(rs.getString("longName"))
                    .build();
            responseFundMasterDtoList.add(responseFundMasterDto);
        }
        con.close();
        return ResponseEntity.ok(new ResponseDto().builder().code(HttpStatus.OK.toString()).message("Berhasil update data S4").payload("").build());
    }
}
