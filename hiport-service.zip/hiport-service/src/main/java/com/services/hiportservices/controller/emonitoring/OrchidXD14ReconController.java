package com.services.hiportservices.controller.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd13;
import com.services.hiportservices.model.emonitoring.OrchidXd14Recon;
import com.services.hiportservices.service.emonitoring.OrchidXd13Service;
import com.services.hiportservices.service.emonitoring.OrchidXd14ReconService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd14Recon")
public class OrchidXD14ReconController {
    @Autowired
    OrchidXd14ReconService reconService;
    Logger logger = LoggerFactory.getLogger(OrchidXD14ReconController.class);


    @GetMapping("/getDataXD14Recon")
    public List<OrchidXd14Recon> getDataXD14Recon(

            @RequestParam(name = "date", required = false) String date

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);

        return reconService.getDataXD14Recon(date);
    }
}
