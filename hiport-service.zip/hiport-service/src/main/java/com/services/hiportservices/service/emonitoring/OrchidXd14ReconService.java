package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd13;
import com.services.hiportservices.model.emonitoring.OrchidXd14Recon;
import com.services.hiportservices.repository.emonitoring.OrchidXd13Repository;
import com.services.hiportservices.repository.emonitoring.OrchidXd14ReconRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OrchidXd14ReconService {
    @Autowired
    OrchidXd14ReconRepository reconRepository;

    public List<OrchidXd14Recon> getDataXD14Recon(String date) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        try {
            Date dateParm = sdf.parse(date);

            return reconRepository.findAllByTanggal(dateParm);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
