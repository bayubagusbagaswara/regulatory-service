package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class PortfolioKINVGroupingRequestDTO {
    private Long id;
    private String reksadanaCode;
    private String rdExternalCode;
    private String portfolio;
    private int portfolioType;
    private String kinvCode;
}
