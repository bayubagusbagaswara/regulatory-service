package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;

import java.util.List;

public interface RegulatoryDataChangeService {

    RegulatoryDataChange getById(Long id);

    List<RegulatoryDataChange> getAll();

    List<String> findAllMenu();

    String deleteAll();

    void setApprovalStatusIsRejected(RegulatoryDataChangeDTO dataChangeDTO, List<String> errorMessageList);

    void setApprovalStatusIsApproved(RegulatoryDataChangeDTO dataChangeDTO);

    <T> void createChangeActionAdd(RegulatoryDataChangeDTO dataChangeDTO, Class<T> clazz);

    <T> void createChangeActionEdit(RegulatoryDataChangeDTO dataChangeDTO, Class<T> clazz);

    <T> void createChangeActionDelete(RegulatoryDataChangeDTO dataChangeDTO, Class<T> clazz);

    Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus approvalStatus);

    boolean existById(Long id);

    List<RegulatoryDataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus);

    void reject(Long id);

    List<RegulatoryDataChange> getAllByApprovalStatus(String approvalStatus);

    String deleteById(Long id);

}
