package com.services.hiportservices.model;

import com.services.hiportservices.enums.ChangeAction;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
//@Table(name = "data_change")
public class DataChange extends Approvable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private ChangeAction action;

    @Column(name = "entityClassName")
    private String entityClassName;

    @Column(name = "entityIdType" )
    private String entityIdType;

    @Column(name ="entityId")
    private String entityId;
    @Column(name = "inputerIPAddress")
    private String inputerIPAddress;
    @Column(name = "approverIPAddress")
    private String approverIPAddress;

    @Lob
    @Column(name = "changedObject")
    private byte[] changedObject;

}
