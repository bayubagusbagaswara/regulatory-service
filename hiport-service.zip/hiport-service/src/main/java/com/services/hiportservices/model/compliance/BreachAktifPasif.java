
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_breach_aktif_pasif")
public class BreachAktifPasif {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "pf_external_code")
    private String pfExternalCode;

    @Column(name = "jatuh_tempo")
    private Date jatuhTempo;

    @Column(name = "past_jatuh_tempo")
    private Date pastJatuhTempo;

    @Column(name = "jumlah_before")
    private double jumlahBefore;

    @Column(name = "jumlah_after")
    private double jumlahAfter;

    @Column(name = "isRedemption")
    private boolean isRedemption;

    @Column(name = "status")
    private String status;
}
