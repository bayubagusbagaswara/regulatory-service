package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface PortfolioKINVGroupingRepository extends JpaRepository<PortfolioKINVGrouping,Long> {
    @Query("SELECT u FROM PortfolioKINVGrouping u WHERE u.reksadanaCode = :reksadanaCode and u.approvalStatus = 'Approved'")
    List<PortfolioKINVGrouping> searchByReksadanaCode(
            @Param("reksadanaCode") Reksadana reksadanaCode);

    @Query("SELECT u FROM PortfolioKINVGrouping u WHERE u.reksadanaCode = :reksadanaCode and u.portfolio = :portfolio and u.approvalStatus = 'Approved'")
    PortfolioKINVGrouping searchByReksadanaCodeAndPortfolio(
            @Param("reksadanaCode") Reksadana reksadanaCode,
            @Param("portfolio") Portfolio portfolio);

    @Transactional
    @Modifying
    @Query("DELETE FROM PortfolioKINVGrouping f where f.reksadanaCode= :reksadanaCode and f.portfolio = :portfolio")
    void deleteMappingPortfolio(@Param("reksadanaCode") Reksadana reksadanaCode,
                    @Param("portfolio") Portfolio portfolio);

    @Query("SELECT u FROM PortfolioKINVGrouping u WHERE  u.approvalStatus = 'Pending'")
    List<PortfolioKINVGrouping> searchPendingMappingData();

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_mapping_portfolio SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE id = :id", nativeQuery = true)
    void approveOrRejectMappingPortfolio(@Param("approvalStatus") String approvalStatus,
                                  @Param("approveDate") Date approveDate,
                                  @Param("approverId") String approverId,
                                  @Param("id") Long id);
}
