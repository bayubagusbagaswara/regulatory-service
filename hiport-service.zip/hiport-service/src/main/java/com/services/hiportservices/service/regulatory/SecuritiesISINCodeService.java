package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.isincode.*;

import java.util.List;

public interface SecuritiesISINCodeService {

    ISINCodeResponse createMultipleData(CreateISINCodeListRequest createISINCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ISINCodeResponse createSingleData(CreateISINCodeRequest createISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ISINCodeResponse createSingleApprove(ISINCodeApproveRequest isinCodeApproveRequest, String approveIPAddress);

    ISINCodeResponse updateMultipleData(UpdateISINCodeListRequest updateISINCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ISINCodeResponse updateSingleData(UpdateISINCodeRequest updateISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ISINCodeResponse updateSingleApprove(ISINCodeApproveRequest isinCodeApproveRequest, String approveIPAddress);

    ISINCodeResponse deleteSingleData(DeleteISINCodeRequest deleteISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ISINCodeResponse deleteSingleApprove(ISINCodeApproveRequest isinCodeApproveRequest, String approveIPAddress);

    ISINCodeDTO getById(Long id);

    ISINCodeDTO getByExternalCode(String externalCode);

    List<ISINCodeDTO> getAll();
}
