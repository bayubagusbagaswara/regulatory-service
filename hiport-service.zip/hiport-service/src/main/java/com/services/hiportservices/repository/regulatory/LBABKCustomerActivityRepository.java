package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LBABKCustomerActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LBABKCustomerActivityRepository extends JpaRepository<LBABKCustomerActivity, Long> {
}
