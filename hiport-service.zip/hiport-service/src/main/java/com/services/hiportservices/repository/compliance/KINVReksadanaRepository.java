package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.KINVReksadana;
import com.services.hiportservices.model.compliance.MasterKebijakanInvestasi;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.compliance.Reksadana;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface KINVReksadanaRepository extends JpaRepository<KINVReksadana,Long> {
    @Query("SELECT u FROM KINVReksadana u WHERE u.approvalStatus = :approvalStatus and u.reksadanaCode = :reksadanaCode and u.kinvCode = :kinvCode")
    KINVReksadana checkDataExistOrNot(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("reksadanaCode") Reksadana reksadanaCode,
            @Param("kinvCode") MasterKebijakanInvestasi kinvCode);

    @Query(value="SELECT * FROM comp_kinv_reksadana WHERE reksadana_code = :reksadanaCode", nativeQuery = true)
    List<KINVReksadana> getAllByReksadanaCode(@Param("reksadanaCode") String reksadanaCode);

    List<KINVReksadana> findAllByApprovalStatusAndReksadanaCode(ApprovalStatus approvalStatus, Reksadana reksadanaCode);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_kinv_reksadana SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE id_kinv_rd = :id", nativeQuery = true)
    void approveOrRejectKinvReksadana(@Param("approvalStatus") String approvalStatus,
                                     @Param("approveDate") Date approveDate,
                                     @Param("approverId") String approverId,
                                     @Param("id") Long id);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_kinv_reksadana SET  rd_external_code = :externalCode " +
            "WHERE reksadana_code = :reksadanaCode", nativeQuery = true)
    void updateExternalCodeWhereCode(@Param("externalCode") String externalCode,
                                      @Param("reksadanaCode") String reksadanaCode);

    @Query("SELECT u FROM KINVReksadana u WHERE  u.approvalStatus = 'Pending'")
    List<KINVReksadana> searchPendingData();

}
