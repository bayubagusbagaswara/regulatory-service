package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.emonitoring.OrchidXd13;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public interface OrchidXd13Repository extends JpaRepository<OrchidXd13,Long> {
//    Date startDate = Date.from(start_date.atZone(ZoneId.systemDefault()).toInstant());
    List<OrchidXd13> findAllByTanggal(Date tanggal);



    OrchidXd13 findByTanggalAndKode(Date tanggal, String code);


    @Query(value = "SELECT * FROM ORCHIDXD13 WHERE tanggal = :date and ( Kode = :code or ReksadanaCode = :code)", nativeQuery = true)
    OrchidXd13 searchDataBy(
            @Param("date") String date,
            @Param("code") String code);

}
