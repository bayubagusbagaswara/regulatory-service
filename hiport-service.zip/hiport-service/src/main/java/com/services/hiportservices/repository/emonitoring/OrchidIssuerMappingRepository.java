package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidFundProductCode;
import com.services.hiportservices.model.emonitoring.OrchidIssuerMapping;
import com.services.hiportservices.model.emonitoring.OrchidXd14Recon;
import com.services.hiportservices.model.emonitoring.OrchidXd15;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface OrchidIssuerMappingRepository extends JpaRepository<OrchidIssuerMapping, Long> {

    @Query(value = "SELECT * FROM ORCHIDDATAMAPPINGISSUER WHERE DisplayPortfolio = :displayPf",
            nativeQuery = true)
    OrchidIssuerMapping searchData(
            @Param("displayPf") String displayPf);
}
