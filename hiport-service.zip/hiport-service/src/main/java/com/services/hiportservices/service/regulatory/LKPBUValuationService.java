package com.services.hiportservices.service.regulatory;

public interface LKPBUValuationService {

    String readAndInsertToDB();

    // get all by month and year
}
