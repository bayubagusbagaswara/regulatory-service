package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.BreachTNABMinimum;
import com.services.hiportservices.model.compliance.DanaKelolahanRecord;
import com.services.hiportservices.model.compliance.PUPRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DanaKelolahanRecorRepository extends JpaRepository<DanaKelolahanRecord,Long> {

    @Query(value="SELECT * FROM comp_dana_kelolahan_record WHERE reksadana_code = :reksadanaCode OR rd_external_code = :rdExternalCode", nativeQuery = true)
    DanaKelolahanRecord searchDataByReksadanaCodeAndExternalCode(@Param("reksadanaCode") String reksadanaCode,
                                         @Param("rdExternalCode") String rdExternalCode);

    @Query("SELECT u FROM DanaKelolahanRecord u")
    List<DanaKelolahanRecord> searchAllDanaKelolahanRecord();

    @Query(value="SELECT * FROM comp_dana_kelolahan_record WHERE changes_date <> :changeDate", nativeQuery = true)
    List<DanaKelolahanRecord> searchAllDanaKelolahanNotInDate(@Param("changeDate") String changeDate);
}
