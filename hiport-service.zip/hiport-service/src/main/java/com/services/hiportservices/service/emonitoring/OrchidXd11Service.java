package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.repository.emonitoring.OrchidXd11Repository;
import com.services.hiportservices.utils.ConfigPropertiesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;

@Service
public class OrchidXd11Service {
    @Autowired
    OrchidXd11Repository orchidXd11Repository;

    public Callable<List<OrchidXd11>> insertOrUpdateAllAsync(String date, String pf, String group) {
        return () -> {
            try {
                List<OrchidXd11> result = insertOrUpdateAll(date, pf, group);
                return result;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
    }

    public List<OrchidXd11> insertOrUpdateAll(String date, String pf, String group)
            throws SQLException, ClassNotFoundException, IOException {

        List<OrchidXd11> listOrchid = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        String className = ConfigPropertiesUtil.getProperty("hiport.className", "connection.properties");
        String ip = ConfigPropertiesUtil.getProperty("hiport.ip", "connection.properties");
        String port = ConfigPropertiesUtil.getProperty("hiport.port", "connection.properties");
        String dataSource = ConfigPropertiesUtil.getProperty("hiport.ServerDataSource", "connection.properties");
        String user = ConfigPropertiesUtil.getProperty("hiport.user", "connection.properties");
        String pass = ConfigPropertiesUtil.getProperty("hiport.password", "connection.properties");

        try {
            Date dateParm = sdf.parse(date);

            if (pf == null || pf.isEmpty()) {
                System.out.println("delete all");
                orchidXd11Repository.deleteAllOrchidXd11(dateParm);
            } else {
                System.out.println("pf " + pf);
                orchidXd11Repository.deleteOrchidXd11(dateParm, pf);

            }

            Class.forName(className);

            String urlConn = "jdbc:DRO://" + ip + ":" + port +
                    ";ServerDataSource=" + dataSource + ";USER=" + user + ";PASSWORD=" + pass;
            System.out.println(urlConn);

            Connection con = DriverManager.getConnection(urlConn);

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(queryInsert(date, pf, group));
            while (rs.next()) {
//            OrchidXd11 orchidXd11 = Optional.of(orchidXd11Repository.findByTanggalAndKode(rs.getDate("Tanggal"),
//                    rs.getString("Kode"))).orElse(new OrchidXd11());
                if (rs.getString("Kode") != null) {
                    OrchidXd11 orchidXd11 = orchidXd11Repository.findByTanggalAndKode(rs.getDate("Tanggal"),
                            rs.getString("Kode"));
                    if (orchidXd11 == null) {
                        orchidXd11 = new OrchidXd11();
                    }
                    orchidXd11.setDateProc(rs.getDate("DATE_PROC"));
                    orchidXd11.setStatProc(rs.getString("STAT_PROC"));
                    orchidXd11.setTanggal(rs.getDate("Tanggal"));
                    orchidXd11.setKode(rs.getString("Kode"));
                    orchidXd11.setInvUang(toDoubleValue(rs.getString("InvUang")));
                    orchidXd11.setInvHutang(toDoubleValue(rs.getString("InvHutang")));
                    orchidXd11.setInvSaham(toDoubleValue(rs.getString("InvSaham")));
                    orchidXd11.setInvWarran(toDoubleValue(rs.getString("InvWarran")));
                    orchidXd11.setKas(toDoubleValue(rs.getString("Kas")));
                    orchidXd11.setPDividend(toDoubleValue(rs.getString("PDividend")));
                    orchidXd11.setPBunga(toDoubleValue(rs.getString("PBunga")));
                    orchidXd11.setPEfek(rs.getBigDecimal("PEfek"));
                    orchidXd11.setPlain(toDoubleValue(rs.getString("Plain")));
                    orchidXd11.setALain(toDoubleValue(rs.getString("ALain")));
                    orchidXd11.setTaktiva(toDoubleValue(rs.getString("TAKTIVA")));
                    orchidXd11.setUfek(toDoubleValue(rs.getString("UFek")));
                    orchidXd11.setULain(toDoubleValue(rs.getString("ULain")));
                    orchidXd11.setTkewajiban(toDoubleValue(rs.getString("TKEWAJIBAN")));
                    orchidXd11.setJmlPenyertaan(toDoubleValue(rs.getString("JmlPenyertaan")));
                    orchidXd11.setAkumulasi(toDoubleValue(rs.getString("Akumulasi")));
                    orchidXd11.setLrRreal(toDoubleValue(rs.getString("LRReal")));
                    orchidXd11.setLrUnreal(toDoubleValue(rs.getString("LRUnreal")));
                    orchidXd11.setPInvest(toDoubleValue(rs.getString("PInvest")));
                    orchidXd11.setTAbersih(toDoubleValue(rs.getString("TABERSIH")));
                    orchidXd11.setJumlahUnit(toDoubleValue(rs.getString("JumlahUnit")));
                    orchidXd11.setReksadanaCode(rs.getString("reksadanaCode"));

                    double nav = (rs.getBigDecimal("NAV") == null) ? 0.0 : rs.getBigDecimal("NAV").doubleValue();
                    orchidXd11.setNav(BigDecimal.valueOf(nav));

                    double absPelunasan = Math.abs(toDoubleValue(rs.getString("Pelunasan")).doubleValue());
                    double absPendapatan = Math.abs(toDoubleValue(rs.getString("Pendapatan")).doubleValue());

                    orchidXd11.setPendapatan(BigDecimal.valueOf(absPendapatan));
                    orchidXd11.setPelunasan(BigDecimal.valueOf(absPelunasan));


                    double saham_lr = (orchidXd11.getJmlPenyertaan().doubleValue() - absPelunasan) + (orchidXd11.getAkumulasi().doubleValue() - absPendapatan) + (
                            orchidXd11.getLrUnreal().doubleValue() + orchidXd11.getLrRreal().doubleValue() + orchidXd11.getPInvest().doubleValue());
                    double notes = saham_lr - orchidXd11.getTAbersih().doubleValue();

                    orchidXd11.setNotes(BigDecimal.valueOf(notes));
                    orchidXd11.setTSahamLr(BigDecimal.valueOf(saham_lr));

                    listOrchid.add(orchidXd11);
                }
            }
            con.close();


            return orchidXd11Repository.saveAll(listOrchid);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private BigDecimal toDoubleValue(String data) {
        String doubleData = "0.00";
        if (data != null) {
            if (data.isEmpty())
                data = "0.00";
            else
                doubleData = data.contains("-") ?
                        "-" + data.replace("-", "").trim()
                        : data.trim();
        } else {
            data = "0.00";
        }

        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    private String queryInsert(String date, String pf, String group) throws Exception {


        String param = " ";
        if (pf != null && !pf.isEmpty()) {
            param = "   PortfolioCode in ('" + pf + "')\n" +
                    "   AND \n";
        }

        System.out.println(param);

        String query = ConfigPropertiesUtil.getAllValue("xd11.properties");
        query = query.replace("PORTFOLIOPARAM", param);
        query = query.replace("DATEPARAM", date);
        query = query.replace("GROUPPARAM", group);

        return query;
    }

    public List<OrchidXd11> getDataXD11(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd11> listOrchid = new ArrayList<>();
        System.out.println("get code: " + pfCode);
        try {
            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {
                listOrchid.addAll(orchidXd11Repository.findAllByTanggal(dateParm));
            } else {
                listOrchid.add(orchidXd11Repository.searchDataBy(date, pfCode));
                System.out.println(listOrchid.size());
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
