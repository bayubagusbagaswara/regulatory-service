package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.*;
import com.services.hiportservices.repository.regulatory.OwnerGroupRepository;
import com.services.hiportservices.service.regulatory.OwnerGroupService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class OwnerGroupServiceImpl implements OwnerGroupService {

    private final OwnerGroupRepository ownerGroupRepository;

    @Override
    public OwnerGroupResponse uploadListData(UploadOwnerGroupListRequest uploadOwnerGroupListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        // terapkan create dan update
        return null;
    }

    @Override
    public OwnerGroupResponse createSingleData(CreateOwnerGroupRequest createOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public OwnerGroupResponse createSingleApprove(OwnerGroupApproveRequest ownerGroupApproveRequest, String clientIP) {
        return null;
    }

    @Override
    public OwnerGroupResponse updateSingleData(UpdateOwnerGroupRequest updateOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public OwnerGroupResponse updateSingleApprove(OwnerGroupApproveRequest ownerGroupApproveRequest, String clientIP) {
        return null;
    }

    @Override
    public OwnerGroupResponse deleteSingleData(DeleteOwnerGroupRequest deleteOwnerGroupRequest, String clientIP) {
        return null;
    }

    @Override
    public OwnerGroupResponse deleteSingleApprove(OwnerGroupApproveRequest ownerGroupApproveRequest, String clientIP) {
        return null;
    }

    @Override
    public OwnerGroupDTO getById(Long id) {
        return null;
    }

    @Override
    public OwnerGroupDTO getByPortfolioCode(String portfolioCode) {
        return null;
    }

    @Override
    public List<OwnerGroupDTO> getAll() {
        return null;
    }
}
