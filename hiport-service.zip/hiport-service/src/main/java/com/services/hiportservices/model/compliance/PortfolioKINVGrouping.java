package com.services.hiportservices.model.compliance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "fieldHandler"})
@Table(name = "comp_mapping_portfolio")
public class PortfolioKINVGrouping extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name="reksadana_code", nullable=false)
    private Reksadana reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @ManyToOne
    @JoinColumn(name="portfolio_code", nullable=false)
    private Portfolio portfolio;

    @ManyToOne
    @JoinColumn(name="portfolio_type", nullable=false)
    private PortfolioType portfolioType;
}
