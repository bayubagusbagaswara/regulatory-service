package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.RegrepLKPBUValTb;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegrepLKPBUValTbRepository extends JpaRepository<RegrepLKPBUValTb, Long> {
}
