package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.isincode.*;
import com.services.hiportservices.service.regulatory.SecuritiesISINCodeService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Maintenance Kode ISIN Efek
 */
@RestController
@RequestMapping(path = "/api/regulatory/isin-code")
@Slf4j
@RequiredArgsConstructor
public class SecuritiesISINCodeController {

    private static final String BASE_URL_SECURITIES_ISIN_CODE = "/api/regulatory/isin-code";
    private static final String MENU_ISIN_CODE = "Kode ISIN Efek";

    private final SecuritiesISINCodeService securitiesIsinCodeService;

    /* Create List Data */
    @PostMapping(path = "/create-list")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> createMultipleData(@RequestBody CreateISINCodeListRequest createISINCodeListRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(BASE_URL_SECURITIES_ISIN_CODE + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .methodHttp(MENU_ISIN_CODE)
                .build();
        ISINCodeResponse listData = securitiesIsinCodeService.createMultipleData(createISINCodeListRequest, regulatoryDataChangeDTO);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Create Single Data (in addition) */
    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> createSingleData(@RequestBody CreateISINCodeRequest createISINCodeRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(BASE_URL_SECURITIES_ISIN_CODE + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ISIN_CODE)
                .build();
        ISINCodeResponse singleData = securitiesIsinCodeService.createSingleData(createISINCodeRequest, regulatoryDataChangeDTO);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Create Single Approve */
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> createSingleApprove(@RequestBody ISINCodeApproveRequest isinCodeApproveRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        ISINCodeResponse singleApprove = securitiesIsinCodeService.createSingleApprove(isinCodeApproveRequest, clientIP);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Update List Data */
    @PutMapping(path = "/update-list")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> updateMultipleData(@RequestBody UpdateISINCodeListRequest updateISINCodeListRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .menu(HttpMethod.PUT.name())
                .endpoint(BASE_URL_SECURITIES_ISIN_CODE + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ISIN_CODE)
                .build();
        ISINCodeResponse listData = securitiesIsinCodeService.updateMultipleData(updateISINCodeListRequest, regulatoryDataChangeDTO);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Update Single Data (in addition) */
    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> updateSingleData(@RequestBody UpdateISINCodeRequest updateISINCodeRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(clientIP)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(BASE_URL_SECURITIES_ISIN_CODE + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ISIN_CODE)
                .build();
        ISINCodeResponse singleData = securitiesIsinCodeService.updateSingleData(updateISINCodeRequest, regulatoryDataChangeDTO);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Update Single Approve */
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> updateSingleApprove(@RequestBody ISINCodeApproveRequest isinCodeApproveRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        ISINCodeResponse singleApprove = securitiesIsinCodeService.updateSingleApprove(isinCodeApproveRequest, approveIPAddress);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Delete Single Data */
    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> deleteSingleData(@RequestBody DeleteISINCodeRequest deleteISINCodeRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(inputIPAddress)
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_SECURITIES_ISIN_CODE + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .build();
        ISINCodeResponse singleData = securitiesIsinCodeService.deleteSingleData(deleteISINCodeRequest, regulatoryDataChangeDTO);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* Delete Single Approve */
    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDto<ISINCodeResponse>> deleteSingleApprove(@RequestBody ISINCodeApproveRequest isinCodeApproveRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        ISINCodeResponse singleApprove = securitiesIsinCodeService.deleteSingleApprove(isinCodeApproveRequest, approveIPAddress);
        ResponseDto<ISINCodeResponse> response = ResponseDto.<ISINCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* get by id */
    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDto<ISINCodeDTO>> getById(@PathVariable("id") Long id) {
        ISINCodeDTO isinCodeDTO = securitiesIsinCodeService.getById(id);
        ResponseDto<ISINCodeDTO> response = ResponseDto.<ISINCodeDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(isinCodeDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    /* get by external code */
    @GetMapping(path = "/external-code")
    public ResponseEntity<ResponseDto<ISINCodeDTO>> getByExternalCode(@RequestParam("externalCode") String externalCode) {
        ISINCodeDTO isinCodeDTO = securitiesIsinCodeService.getByExternalCode(externalCode);
        ResponseDto<ISINCodeDTO> response = ResponseDto.<ISINCodeDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(isinCodeDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    /* get all */
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<ISINCodeDTO>>> getAll() {
        List<ISINCodeDTO> isinCodeDTOList = securitiesIsinCodeService.getAll();
        ResponseDto<List<ISINCodeDTO>> response = ResponseDto.<List<ISINCodeDTO>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(isinCodeDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
