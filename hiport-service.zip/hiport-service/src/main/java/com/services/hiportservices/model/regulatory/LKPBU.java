package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * ini untuk data regulatory LKPBU setelah diolah
 */
@Entity
@Table(name = "regulatory_lkpbu")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBU {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kode_komponen")
    private String kodeKomponen;


}
