package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.MappingKINVRequestDTO;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.dto.request.compliance.ReksadanaRequestDTO;
import com.services.hiportservices.service.compliance.PortfolioService;
import com.services.hiportservices.service.compliance.ReksadanaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/reksadana")
public class ReksadanaController {
    @Autowired
    ReksadanaService reksadanaService;

    @PostMapping
    public ResponseEntity<ResponseDto> save(@RequestBody MappingKINVRequestDTO mappingKINVRequestDTO)  {
        return reksadanaService.insertReksadanaManual(mappingKINVRequestDTO);
    }

    @PutMapping("/upload/{param}")
    public ResponseEntity<ResponseDto> uploadFileReksadana(@PathVariable String param, @RequestBody List<Map<String, String>> reksadanaList) {
        return reksadanaService.insertReksadanaUpload(param, reksadanaList);
    }

    @GetMapping("/all")
    public ResponseEntity<ResponseDto> getAllReksadana()  {
        return reksadanaService.findAllReksadana();
    }

    @GetMapping
    public ResponseEntity<ResponseDto> searchPortfolio(@RequestParam String findByCode)  {
        return reksadanaService.searchReksadana(findByCode);
    }

    @GetMapping("/{code}")
    public ResponseEntity<ResponseDto> getByCode(@PathVariable String code)  {
        return reksadanaService.getByCode(code);
    }

    @GetMapping("view")
    public ResponseEntity<ResponseDto> getPendingReksadanaByCode(@RequestParam String code)  {
        return reksadanaService.getPendingReksadanaByCode(code);
    }

    @PutMapping("/delete/{code}")
    public ResponseEntity<ResponseDto> deleteById(@PathVariable String code)  {
        return reksadanaService.deleteByCode(code);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return reksadanaService.allPendingDataReksadana();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return reksadanaService.approveDataReksadana(codeList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return reksadanaService.rejectDataReksadana(codeList);
    }
}
