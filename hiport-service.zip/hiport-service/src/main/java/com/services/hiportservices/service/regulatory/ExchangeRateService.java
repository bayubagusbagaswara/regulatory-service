package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.exchangerate.*;

import java.util.List;

public interface ExchangeRateService {

    ExchangeRateResponse createSingleData(CreateExchangeRateRequest createExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ExchangeRateResponse createSingleApprove(String approveIPAddress, ExchangeRateApproveRequest exchangeRateApproveRequest);

    ExchangeRateResponse updateSingleData(UpdateExchangeRateRequest updateExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ExchangeRateResponse updateSingleApprove(ExchangeRateApproveRequest exchangeRateApproveRequest, String clientIP);

    ExchangeRateResponse deleteSingleData(DeleteExchangeRateRequest deleteExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    ExchangeRateResponse deleteSingleApprove(ExchangeRateApproveRequest exchangeRateApproveRequest, String clientIP);

    ExchangeRateDTO getById(Long id);

    ExchangeRateDTO getByCurrencyCode(String currencyCode);

    ExchangeRateDTO getByCurrencyName(String currencyName);

    List<ExchangeRateDTO> getAll();

}
