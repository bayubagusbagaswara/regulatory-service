package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.regulatory.approval.RegulatoryApproval;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "regulatory_issuer_code_placement_bank")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class IssuerCodePlacementBank extends RegulatoryApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code")
    private String code;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "bank_type")
    private String bankType;

    @Column(name = "issuer_group")
    private String issuerGroup;

    @Column(name = "issuer_country")
    private String issuerCountry;

    @Column(name = "bond_type")
    private String bondType;

    @Column(name = "securities_type_code")
    private String securitiesTypeCode;

    @Column(name = "status")
    private String status;

    @Column(name = "currency")
    private String currency;

}
