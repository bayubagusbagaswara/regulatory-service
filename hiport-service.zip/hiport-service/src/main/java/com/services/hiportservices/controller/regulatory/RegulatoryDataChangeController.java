package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/regulatory/data-change")
@Slf4j
@RequiredArgsConstructor
public class RegulatoryDataChangeController {

    private final RegulatoryDataChangeService dataChangeService;



}
