package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.FairPrice;
import com.services.hiportservices.model.compliance.IDXPrice;
import com.services.hiportservices.model.compliance.Redemption;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface RedemptionRepository extends JpaRepository<Redemption,Long> {

    @Query("SELECT u FROM Redemption u WHERE u.transactionDate = :transactionDate and u.approvalStatus = 'Approved'")
    List<Redemption> searchByDataDate(@Param("transactionDate") Date transactionDate);

    @Query("SELECT u FROM Redemption u WHERE u.transactionDate = :transactionDate and u.fundCode = :fundCode and u.referenceNo = :referenceNo")
    Redemption searchForChecking(@Param("transactionDate") Date transactionDate,
                                 @Param("fundCode") String fundCode,
                                 @Param("referenceNo") String referenceNo);

    @Query("SELECT u FROM Redemption u WHERE u.transactionDate = :date and u.approvalStatus = 'Pending'")
    List<Redemption> searchPendingData(@Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_redemption SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverrId " +
            "WHERE transaction_date = :dataDate", nativeQuery = true)
    void approveOrRejectFairPrice(@Param("approvalStatus") String approvalStatus,
                                  @Param("approveDate") Date approveDate,
                                  @Param("approverrId") String approverrId,
                                  @Param("dataDate") String dataDate);

}
