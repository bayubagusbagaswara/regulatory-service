package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.KinvDetails;
import com.services.hiportservices.model.compliance.MasterKebijakanInvestasi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface KinvDetailsRepository extends JpaRepository<KinvDetails,Long> {
    @Transactional
    @Modifying
    @Query(value="INSERT INTO comp_kinv_details (kinv_code, portfolio_type)"
            + " VALUES (:kinvCode, :portfolioType)", nativeQuery = true)
    void insertKinvDetails(@Param("kinvCode") String kinvCode,
                            @Param("portfolioType") int portfolioType);

    KinvDetails findByKinvCodeAndPortfolioType (String kinvCode, int portfolioType);

    List<KinvDetails> findAllByKinvCode(String kinvCode);

    @Transactional
    @Modifying
    @Query(value="DELETE comp_kinv_details WHERE kinv_code = :kinvCode and portfolio_type = :portfolioType", nativeQuery = true)
    void deleteKinvDetails(@Param("kinvCode") String kinvCode,
                           @Param("portfolioType") int portfolioType);

    @Transactional
    @Modifying
    @Query(value="DELETE comp_kinv_details WHERE kinv_code = :kinvCode", nativeQuery = true)
    void deleteAllKinvDetails(@Param("kinvCode") String kinvCode);
}
