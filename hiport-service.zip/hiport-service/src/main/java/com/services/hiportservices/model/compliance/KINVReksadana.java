package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_kinv_reksadana")
public class KINVReksadana extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_kinv_rd")
    private Long id;

    @ManyToOne
    @JoinColumn(name="reksadana_code", nullable=false)
    private Reksadana reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @ManyToOne
    @JoinColumn(name="kinv_code", nullable=false)
    private MasterKebijakanInvestasi kinvCode;

    @Column(name = "percentage_kinv_min")
    private double kinvMin;

    @Column(name = "percentage_kinv_max")
    private double kinvMax;

    @Column(name = "notes")
    private String note;
}
