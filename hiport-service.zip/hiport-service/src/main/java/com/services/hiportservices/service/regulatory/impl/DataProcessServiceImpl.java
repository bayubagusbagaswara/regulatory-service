package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.service.regulatory.DataProcessService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataProcessServiceImpl implements DataProcessService {


    @Override
    public void processData() {

    }
}
