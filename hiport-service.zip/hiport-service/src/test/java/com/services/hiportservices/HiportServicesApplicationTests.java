package com.services.hiportservices;

import com.services.hiportservices.utils.UserIdUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class HiportServicesApplicationTests {
//	@Autowired
//	NfsParmBrokerMasterRepository nfsParmBrokerMasterRepository;
	@Test
	void contextLoads() {
		assertTrue(true);
	}

	@Test
	void testupdate(){
//		nfsParmBrokerMasterRepository.NFSBROKERMASTERSP("HG001","ABNAMP","ABN AMRO SECURITIES INDONESIA","111111");
		assertTrue(true);
	}
}
